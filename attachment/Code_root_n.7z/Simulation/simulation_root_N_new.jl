#!/usr/bin/julia
using Distributions

function kernel(x)
	return exp(-0.5*x.^2)
end

function KernelRegPoint(y,x::Array{Float64},x0::Array{Float64},h::Float64;  discrete=[-1]::Array{Int},LOO=0::Int)
	h=h*std(x,1)*length(y)^(-0.2)
	dx=broadcast(-,x,x0)
	dx=broadcast(/,dx,h)
	kdx=kernel(dx)
	if discrete[1]!=-1
		for i=1:length(discrete)
			d=discrete[i]
			for j=1:length(y)
				if (x0[d]-x[j,d])<1e-3
					kdx[j,d]=1
				else
					kdx[j,d]=0
				end
			end
		end
	end
	k=prod(kdx,2)
	if LOO!=0
		k[LOO]=0.0
	end
	return sum(y.*k)/sum(k)
end

function KernelSelfReg(y,x::Array{Float64},h::Float64;  discrete=[-1]::Array{Int},LOO=0::Int)
	yhat=Array(Float64,length(y))
	for i=1:length(y)
		if LOO!=0
			yhat[i]=KernelRegPoint(y,x,x[i,:],h,discrete=discrete,LOO=i)
		else
			yhat[i]=KernelRegPoint(y,x,x[i,:],h,discrete=discrete)
		end
	end
	return yhat
end

type Data
	N::Int
	d1::Array{Int64}
	d2::Array{Int64}
	x1::Array{Float64,2}
	x2::Array{Float64,2}
	XX11::Array{Float64,2}
	XX12::Array{Float64,2}
	XX13::Array{Float64,2}
	XX21::Array{Float64,2}
	XX22::Array{Float64,2}
	XX23::Array{Float64,2}
end

function DGP(N::Int, rho::Float64)
	Cov=[1 rho; rho 1]^(1/2)
	## x1 and x2
	x11=randn(N)
	x12=randn(N)
	x21=randn(N)
	x22=randn(N)
	Xtemp=[x11 x12]'
	Xtemp=Cov*Xtemp
	x11=Xtemp[1,:]'*sqrt(2)
	x12=Xtemp[2,:]'*sqrt(2)
	Xtemp=[x21 x22]'
	Xtemp=Cov*Xtemp
	x21=Xtemp[1,:]'
	x22=Xtemp[2,:]'
	## x3
	x13=rand(N)*6-3
	x23=randn(N).^2-1
	## x4
	x14=randn(N)
	x24=randn(N)
	## yita
	yita=rand(N)*4-2+(x14+x24-1).*(sqrt((1+x23)).*abs(x13)./(1+exp(0.5*(x12+x22))))
	## u
	u=rand(N)-0.5
	u1=-1*sqrt(2)*sign(u).*log(1-2*abs(u))/sqrt(2)
	u=rand(N).<0.5
	u_1=randn(N)-2
	dist=Gamma(2,2)
	u_2=invlogcdf(dist,log(rand(N)))/(2*sqrt(2))+2-sqrt(2)
	u2=(u.*u_1+(1-u).*u_2)/sqrt(2)
	## XX
	XX11=Array(Float64,N,N)
	XX12=Array(Float64,N,N)
	XX13=Array(Float64,N,N)
	XX21=Array(Float64,N,N)
	XX22=Array(Float64,N,N)
	XX23=Array(Float64,N,N)
	for i=1:N
		for j=1:N
			XX11[i,j]=x11[i]-x11[j]
			XX11[j,i]=XX11[i,j]
			XX12[i,j]=x12[i]-x12[j]
			XX12[j,i]=XX12[i,j]
			XX13[i,j]=x13[i]-x13[j]
			XX13[j,i]=XX13[i,j]
			XX21[i,j]=x21[i]-x21[j]
			XX21[j,i]=XX21[i,j]
			XX22[i,j]=x22[i]-x22[j]
			XX22[j,i]=XX22[i,j]
			XX23[i,j]=x23[i]-x23[j]
			XX23[j,i]=XX23[i,j]
		end
	end
	## data
	d1=(x11-x12-x13+x14+yita+u1).>0
	d2=(x21-x22-x23+x24+yita+u2).>0
	return Data(N,vec(d1),vec(d2),[x11 x12 x13 x14],[x21 x22 x23 x24],XX11,XX12,XX13,XX21,XX22,XX23)
end

function CrossValid_obj(h::Float64, data::Data)
	N=data.N
	K=size(data.x1,2)
	trim=0.025
	X=[data.x1 data.x2]
	obj=0.0
	for i=1:N
		## get p LOO
		d1hat=KernelSelfReg(data.d1,[data.x1 data.x2],h,LOO=i)
		d2hat=KernelSelfReg(data.d2,[data.x1 data.x2],h,LOO=i)
		trimming=(d1hat.<(1-trim)) & (d2hat.<(1-trim)) & (d1hat.>trim) & (d2hat.>trim)
		R_Y=data.x1[:,1]-data.x2[:,1]
		R_X=[data.x1[:,2:end]-data.x2[:,2:end] ones(N) d1hat d1hat.^2 d1hat.^3 d2hat d2hat.^2 d2hat.^3]
		R_Y[i]=0
		R_X[i,:]=zeros(7+K-1)'
		R_Y=R_Y[trimming]
		R_X=R_X[trimming,:]
		beta=vec((R_X'*R_X)\(R_X'*R_Y))
		xi=([data.x1[i,2:end]-data.x2[i,2:end] 1 d1hat[i] d1hat[i]^2 d1hat[i]^3 d2hat[i] d2hat[i]^2 d2hat[i]^3]*beta)[1]
		obj+=(xi-(data.x1[i,1]-data.x2[i,1]))^2
		# println(beta[1:K-1])
	end
	return obj/N
end

function CrossValid(data::Data)
	minobj=Inf
	minh=0
	for h=5:2:15
		obj=CrossValid_obj(float(h),data)
		if obj<minobj
			minobj=obj
			minh=h
		end
	end
	for h=minh-2:0.5:minh+2
		obj=CrossValid_obj(float(h),data)
		if obj<minobj
			minobj=obj
			minh=h
		end
	end
	return minh
end

function estimate(data::Data)
	N=data.N
	h=CrossValid(data)
	K=size(data.x1,2)
	X=[data.x1 data.x2]
	trim=0.025
	d1hat=KernelSelfReg(data.d1,X,float(h))
	d2hat=KernelSelfReg(data.d2,X,float(h))
	trimming=(d1hat.<(1-trim)) & (d2hat.<(1-trim)) & (d1hat.>trim) & (d2hat.>trim)
	R_Y=data.x1[:,1]-data.x2[:,1]
	R_X=[data.x1[:,2:end]-data.x2[:,2:end] ones(N) d1hat d1hat.^2 d1hat.^3 d2hat d2hat.^2 d2hat.^3]
	R_Y=R_Y[trimming]
	R_X=R_X[trimming,:]
	beta=vec((R_X'*R_X)\(R_X'*R_Y))
	return beta[1:K-1]
end

M=100
srand(1988)
True_Beta=[1 1 -1]
BETA=Array(Float64,M,3)
for i=1:M
	data=DGP(300, 0.0)
	@time beta=estimate(data)
	BETA[i,:]=beta
	# println(size(mean(BETA[1:i,:],1)))
	bias=mean(BETA[1:i,:],1)-True_Beta
	println("beta=$(beta), bias=$(bias)")
end
