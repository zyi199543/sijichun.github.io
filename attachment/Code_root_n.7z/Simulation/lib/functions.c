double normcdf(double x){
	double abs_x=sgn(x)*x;
	double fi=normpdf(abs_x);
	double b[]={0.2316419,0.31938,-0.35656,1.78148,-1.82125,1.33027};
	double t=1.0/(1+b[0]*abs_x),ti=1.0;
	double s=0.0;
	int i;
	for (i = 1; i < 6; ++i){
		ti*=t;
		s+=b[i]*ti;
	}
	return ((x>0)?(1-fi*s):fi*s);
}
/*
Algorithm:  http://zh.wikipedia.org/wiki/N%E7%BB%B4%E7%90%83%E9%9D%A2
the range of theta:
    If the dimension of x is K, then:
        range(theta_K1 - theta_K-1)=[0,pi)
        range(theta_K)=[0,2pi)
Default radius=1

K: the dimension of x, note that dim(theta)=K-1, and K must be larger than 1.
*/
void euclid2ball(double *theta, double const *x, int const K){
	int k;
	double sumsq=0.0;
	int all=0;
	for (k = 0; k < K; ++k){
		if (*(x+k)!=0){all=1;break;}
	}
	if (all==0) {printf("Shold not be zero vector.\n");return;}
	if (K>2){
		for (k=K-1;k>=0;--k){
			sumsq+=pow(*(x+k),2);
			if (k!=0 && k!=K-1){
				*(theta+k-1)=atan(sqrt(sumsq)/ *(x+k-1));
				if (*(theta+k-1)<0) *(theta+k-1)+=PI;
				if (sqrt(sumsq)==0.0) *(theta+k-1)=(*(x+k-1)>0)?0:PI;
			}
		}
	}
	if (*(x+K-2)==0.0 && *(x+K-1)==0.0) *(theta+K-2)=0;
	else *(theta+K-2)=atan(*(x+K-1)/ *(x+K-2));
	if (*(theta+K-2)<0) *(theta+K-2)+=PI;
	if ( (*(theta+K-2)<PId2 && *(x+K-2)<0) || (*(theta+K-2)>PId2) && *(x+K-2)>0) *(theta+K-2)+=PI;
	if (*(theta+K-2)==0.0) *(theta+K-2)=*(x+K-2)>=0.0?0:PI;
	if (*(x+K-2)==0.0){*(theta+K-2)=atan(*(x+K-1)/ *(x+K-2))>0?PId2:PId2+PI;}
	if (*(x+K-2)==0.0 && *(x+K-1)==0.0) *(theta+K-2)=PId2;
}

void ball2euclid(double *x, double const *theta, int const K){
	int k;
	double sintheta[K-1];
	double sins=1.0;
	*x=cos(*theta);
	if (K>2){
		for(k=0;k<K-1;++k)
			sintheta[k]=sin(*(theta+k));
		for(k=1;k<K-1;++k){
			sins*=sintheta[k-1];
			*(x+k)=sins*cos(*(theta+k));
		}
		*(x+K-1)=sins*sin(*(theta+K-2));
	}else if(K==2){
		*(x+1)=sin(*theta)*cos(*(theta+1));
	}
}

void demeanMatrixByColumn(gsl_matrix *m){
	double colmean[m->size2];
	int i,j;
	for (i = 0; i < m->size2; ++i)
		colmean[i]=0;
	for (i = 0; i < m->size1; ++i)
		for (j = 0; j < m->size2; ++j)
			colmean[j]+=(gsl_matrix_get(m,i,j)/m->size1);
	for (i = 0; i < m->size1; ++i)
		for (j = 0; j < m->size2; ++j)
			gsl_matrix_set(m,i,j,gsl_matrix_get(m,i,j)-colmean[j]);
}