/*
Author:  Jichun Si
email:   sijichun#gmail.com
Blog:    http://www.sijichun.pro
GitHub:  https://github.com/sijichun
*/

/*
The higher-order kernel
	u:  the data point
	order: the order of the kernel
		0: inf-order    kernel
		2: 2nd-order    normal    kernel
		4: 4th-order    normal    kernel
		6: 6th-order    normal    kernel
		1: 2nd-order Epanechnikov kernel
		3: 4th-order Epanechnikov kernel
		5: 6th-order Epanechnikov kernel
*/

double Kernel(double u, int order){
	double u2;
	double k;
	if (order==0){
		if (fabs(u)<1e-6) return 3*PI/2;
		u2=cos(u);
		k=(1+u2-2*pow(u2,2))/(PI*pow(u,2));
		return k;
	}
	u2=pow(u,2);
	if (order==2) k=exp(-1*u2/2)*0.3989422804014327;
	else if (order==4) k=(1.5-0.5*u2)*exp(-1*u2/2)*0.3989422804014327;
	else if (order==6) k=(1.875-1.25*u2+0.125*pow(u2,2))*exp(-1*u2/2)*0.3989422804014327;
	else if (order==1) k=u2<5?0.33541019662496846*(1-0.2*u2):0;
	else if (order==3) k=u2<5?0.33541019662496846*(1.875-0.875*u2)*(1.0-0.2*u2):0;
	else if (order==5) k=u2<5?0.33541019662496846*(2.734375-3.28125*u2+0.721875*pow(u2,2))*(1-0.2*u2):0;
	return k;
}


/*
The multi dimensional kernel
	x:  the data pointer
	xd: the 
	h:  the bandwidth pointer
	K:  the dimension of the array
	order: the order of the kernel
*/
double MultiKernel(const double *x, const double *xd, const double *h, const int K, int order)
{
	int i;
	double ker=1.0;
	double k;
	for (i = 0; i < K; ++i){
		k=(*(x+i)-*(xd+i))/(*(h+i));
		ker*=((isinf(k)==0)?Kernel(k,order):0);
	}
	return ker;
}

void KernleDensity(double *fx, const double *x, int N, const double *xd, int Nd, double h, int order){
	int i,j;
	for (i = 0; i < Nd; ++i){
		*(fx+i)=0;
		for (j = 0; j < N; ++j)
			*(fx+i)+=Kernel((*(xd+i)-*(x+j))/h,order);
		*(fx+i)/=(N*h);
	}
}

void KernleSelfDensity(double *fx, const double *x, int N, double h, int order, int LOO){
	int i,j;
	double ker;
	for (i=0; i<N; ++i) *(fx+i)=0;
	for (i = 0; i < N; ++i){
		for (j = (LOO==1?i+1:i); j < N; ++j){
			ker=Kernel((*(x+i)-*(x+j))/h,order);
			*(fx+i)+=ker;
			*(fx+j)+=ker;
		}
	}
	for (int i = 0; i < N; ++i)
		*(fx+i)/=(LOO==1?(N-1)*h:N*h);
}

typedef struct
{
	int N;
	int order;
	double *x;
}DensityData;

double DensityCVobj(double h, void *data){
	if (h<=0) return 1e100;
	DensityData *d=(DensityData *)data;
	double fx[d->N], obj=0;
	int i;
	KernleSelfDensity(fx, d->x, d->N, h, d->order, 1);
	for (int i = 0; i < d->N; ++i)
		obj+=log((*(fx+i)>1e-6)?*(fx+i):1e-6);
	obj/=(d->N);
	return -1*obj;
}

double CrossValidDesnsity(double *fx, double *x, int N, int LOO){
	DensityData data;
	int i;
	double h;
	// data
	data.N=N;
	data.order=2;
	data.x=x;
	// find minimum
	double std=gsl_stats_sd(x,1,N)*pow(N,-0.2);
 	double a = 0.01*std, b = 6*std;
 	h=gridSearch1(a, b, 10, 3, &data, DensityCVobj);
	KernleSelfDensity(fx, x, N, h, 2, LOO);
	return h;
}

/*
The Kernel estimation function for each point in xd.
	yhat: the outcome
	y:    the LHS variable
	x:    the RHS variable
	h:    bandwidth
	xd:   the points to computed
	N:    the number of observations
	K:    the number of columns in x
	Nd:   the number of xd
	order: the order of the kernel
*/
void KernelRegs(double *yhat, const double *y, const double *x, const double *h, const double *xd, const int N, const int K, const int Nd, int order){
	int i,n;
	double SUM_K;
	double SUM_Y;
	double ker;
	omp_set_num_threads(CORES);
	for (i = 0; i < Nd; ++i)
	{
		SUM_Y=0.0;
		SUM_K=0.0;
		#pragma omp parallel for reduction(+:SUM_K,SUM_Y) private(ker)
		for (n = 0; n < N; ++n){
			ker=MultiKernel(x+n*K,xd+i*K,h,K,order);
			SUM_K+=ker;
			SUM_Y+=ker*(*(y+n));
		}
		*(yhat+i)=SUM_Y/SUM_K;
	}
}
/*
The Kernel estimation function for each point in x itself.
	yhat: the outcome
	y:    the LHS variable
	x:    the RHS variable
	h:    bandwidth
	N:    the number of observations
	K:    the number of columns in x
	LOO:  1: leave-one-out
		  0: no leave-one-out
	order: the order of the kernel
*/
void KernelSelfRegs(double *yhat, const double *y, const double *x, const double *h, int N, int K, int LOO, int order)
{
	double SUM_K[N],SUM_Y[N];
	int i,j;
	double ker;
	double sk,sy;
	for (i = 0; i < N; ++i) {SUM_K[i]=0.0; SUM_Y[i]=0.0;} // initialize to zero!!!
	for (i=1;i<N;++i){
	  sk=0.0;sy=0.0;
	  #pragma omp parallel for reduction(+:sk,sy) private(ker)
	  for (j=0;j<i;++j){
	    ker=MultiKernel(x+i*K,x+j*K,h,K,order);
	    *(SUM_K+j)+=ker;
	    *(SUM_Y+j)+=(ker*(*(y+i)));
	    sk=sk+ker;
	    sy=sy+ker*(*(y+j));
	  }
	  *(SUM_K+i)+=sk;
	  *(SUM_Y+i)+=sy;
	}
	#pragma omp parallel for
	for (i=0;i<N;++i){
		if (LOO==1)
			*(yhat+i)=*(SUM_Y+i)/(*(SUM_K+i));
		else
			*(yhat+i)=(*(SUM_Y+i)+pow(Kernel(0,order),K)*(*(y+i)))/(*(SUM_K+i)+pow(Kernel(0,order),K));
	}
}

/*********************Cross Validation**********************/
/*
The Objective function for Cross Validation.
*/
// data structure
typedef struct{
	int N;
	int K;
	int order;
	double *y;
	double *x;
	double *h;
}DATA_Nonpara;

double CrossValiObj(const gsl_vector *v, void *params){
	DATA_Nonpara *d=(DATA_Nonpara *)params;
	double *y=d->y;
	double *x=d->x;
	double h[d->K];
	double yhat[d->N];
	int i;
	double sum=0.0;
	double sdy=gsl_stats_sd(y,1,d->N);
	for (i = 0; i < d->K; ++i)
	{
		*(h+i)=gsl_vector_get(v,i);
		if (*(h+i)<=0 || isfinite(*(h+i))==0)
			return 1e100; // the bandwidth should not be 0 or negative.
	}
	KernelSelfRegs(yhat,y,x,h,d->N,d->K,1,d->order);
	for (i = 0; i < d->N; ++i)
		sum+=(isnan(*(yhat+i))?sdy:pow(*(y+i)-*(yhat+i),2));// to avoid the bandwidth to be NaN, we need a punishment, sdy.
	return (double)sum/d->N;
}
/*
The Kernel estimation function for each point in xd.
	h:        bandwidth to be chosen
	yhat:     the outcome
	y:        the LHS variable
	x:        the RHS variable
	N:        the number of observations
	K:        the number of columns in x
	MaxIter:  the maximum iterations
	tol:      the tolerence, maybe 1e-3
	LOO:      Leave-One-Out
	warn:     print the warning message?
*/
void CrossValid(double *h, double *yhat, double *y, double *x, int N, int K, int order, int MaxIter, double tol, int LOO, int warn){
	DATA_Nonpara data;data.N=N;data.K=K;data.y=y;data.x=x;data.order=order;
	gsl_vector *v=gsl_vector_alloc(K);
	gsl_vector *s=gsl_vector_alloc(K);
	gsl_vector *p=gsl_vector_alloc(K);
	// prepare for the minimizer.
	const gsl_multimin_fminimizer_type *T=gsl_multimin_fminimizer_nmsimplex2;
	gsl_multimin_fminimizer *fmini=gsl_multimin_fminimizer_alloc(T,K);
	// prepare for the initial value
	int k;
	for (k = 0; k < K; ++k)
	{
		gsl_vector_set(v,k,pow(N,(double)(-1.0)/(4+K))*gsl_stats_sd(x+k,K,N));
		gsl_vector_set(s,k,gsl_vector_get(v,k));
		gsl_vector_set(p,k,gsl_vector_get(v,k));
	}
	double obj=CrossValiObj(v,&data),obj_new,obj_newnew,h_temp;
	for (int k = 0; k < K; ++k)
	{
		gsl_vector_set(p,k,20*pow(N,(double)(-1.0)/(4+K))*gsl_stats_sd(x+k,K,N));
		obj_new=CrossValiObj(p,&data);
		if (obj_new<obj){
			gsl_vector_set(p,k,300*pow(N,(double)(-1.0)/(4+K))*gsl_stats_sd(x+k,K,N));
			obj_newnew=CrossValiObj(p,&data);
			if (obj_newnew<obj_new){
				h_temp=gsl_vector_get(v,k);
				gsl_vector_set(v,k,gsl_vector_get(p,k));
				gsl_vector_set(s,k,gsl_vector_get(p,k));
				gsl_vector_set(p,k,h_temp);
			}else{
				h_temp=gsl_vector_get(v,k);
				gsl_vector_set(v,k,gsl_vector_get(p,k));
				gsl_vector_set(s,k,gsl_vector_get(p,k)*1.2);
				gsl_vector_set(p,k,h_temp);
			}
		}else{
			gsl_vector_set(s,k,1.2*gsl_vector_get(v,k));
			gsl_vector_set(p,k,gsl_vector_get(v,k));
		}
	}
	// initializing the minimizer
	gsl_multimin_function Obj;
	Obj.n=K;Obj.f=CrossValiObj;Obj.params=&data;
	gsl_multimin_fminimizer_set(fmini,&Obj,v,s);
	// iterate
	int iter=0; int status=0; double size;
	do{
		iter++;
		status=gsl_multimin_fminimizer_iterate(fmini);
		if(status>0 && warn==1){
			printf("The Cross Validation Procedure does not converge....\n");
			break;
		}
		size=gsl_multimin_fminimizer_size(fmini);
		status=gsl_multimin_test_size(size,tol);
	}while(status==GSL_CONTINUE && iter<MaxIter);
	// return result
	for (k=0; k < K; ++k)
		*(h+k)=gsl_vector_get(fmini->x,k);
	KernelSelfRegs(yhat,y,x,h,N,K,LOO,order);
	// free
	gsl_vector_free(s);
	gsl_vector_free(p);
	gsl_vector_free(v);
	gsl_multimin_fminimizer_free(fmini);
}
/*********************Single Index**********************/
double SingleIndexObj(const gsl_vector *v, void *params){
	DATA_Nonpara *d=(DATA_Nonpara *)params;
	int i,j;
	double xbar[d->N],G[d->N];
	double obj=0.0,obj_i;
	double trim=0.01;
	double h=gsl_vector_get(v,0);
	if (h<=1e-5)
		return 1e5;
	for (i = 0; i < d->N; ++i)
	{
		*(xbar+i)=*(d->x+d->K*i);
		for (j = 1; j < d->K; ++j)
			*(xbar+i)+=gsl_vector_get(v,j)**(d->x+d->K*i+j);
		*(xbar+i)=*(xbar+i)>1e5?1e5:*(xbar+i);
		*(xbar+i)=*(xbar+i)<-1e5?-1e5:*(xbar+i);
	}
	KernelSelfRegs(G,d->y,xbar,&h,d->N,1,1,d->order);
	for (i = 0; i < d->N; ++i){
		if (*(G+i)>(1.0-trim)) *(G+i)=1.0-trim;
		if (*(G+i)< trim ) *(G+i)=trim;
		if (isnan(*(G+i))) *(G+i)=(*(d->y+i)>0.5)?(1-trim):trim;
		obj+=(*(d->y+i)>0.5?log(*(G+i)):log(1-*(G+i)));
	}
	return -1*obj/d->N;
}
void SingleIndex(double *b, double *y, double *x, int N, int K, int order, int MaxIter, double tol, int warn){
	DATA_Nonpara data;data.N=N;data.K=K;data.y=y;data.x=x;data.order=order;
	gsl_vector *v=gsl_vector_alloc(K);
	gsl_vector *s=gsl_vector_alloc(K);
	// prepare for the minimizer.
	const gsl_multimin_fminimizer_type *T=gsl_multimin_fminimizer_nmsimplex2;
	gsl_multimin_fminimizer *fmini=gsl_multimin_fminimizer_alloc(T,K);
	// prepare for the initial value
	int k,i,j;
	gsl_vector *Y=gsl_vector_alloc(N);
	gsl_matrix *X=gsl_matrix_alloc(N,K);
	for (i = 0; i < N; ++i)
	{
		gsl_vector_set(Y,i,(double)*(y+i));
		for (j = 0; j < K; ++j)
			gsl_matrix_set(X,i,j,*(x+K*i+j));
	}
	demeanMatrixByColumn(X);
	LeastSquare(v,Y,X,warn);
	gsl_vector_scale(v,1/gsl_vector_get(v,0));
	for (k = 1; k < K; ++k)
		gsl_vector_set(s,k,1.2*gsl_vector_get(v,k));
	gsl_vector_set(v,0,0.6*pow(N,-1.0/5));
	gsl_vector_set(s,0,0.7*gsl_vector_get(v,1));
	gsl_vector_free(Y);
	gsl_matrix_free(X);
	// initializing the minimizer
	gsl_multimin_function Obj;
	Obj.n=K;Obj.f=SingleIndexObj;Obj.params=&data;
	gsl_multimin_fminimizer_set(fmini,&Obj,v,s);
	// iterate
	int iter=0; int status=0; double size;
	do{
		iter++;
		status=gsl_multimin_fminimizer_iterate(fmini);
		if(status>0 && warn==1){
			printf("The Single Index Procedure does not converge....\n");
			break;
		}
		size=gsl_multimin_fminimizer_size(fmini);
		status=gsl_multimin_test_size(size,tol);
	}while(status==GSL_CONTINUE && iter<MaxIter);
	// return result
	for (k=0; k < K; ++k)
		*(b+k)=gsl_vector_get(fmini->x,k);
	// free
	gsl_vector_free(s);
	gsl_vector_free(v);
	gsl_multimin_fminimizer_free(fmini);
}
/*********************Panel Single Index**********************/
typedef struct{
	int K;
	int T;
	int *N;
	int NT;
	int order;
	double *y;
	double *x;
	double *h;
}RepeatedDATA_Nonpara;
double PanelSingleIndexObj(const gsl_vector *v, void *params){
	RepeatedDATA_Nonpara *d=(RepeatedDATA_Nonpara *)params;
	int i,cumN=0;
	double obj=0.0;
	for (i = 0; i < d->T; ++i){
		DATA_Nonpara data;
		data.N=*(d->N+i);
		data.K=d->K;
		data.x=d->x+cumN*d->K;
		data.y=d->y+cumN;
		data.order=d->order;
		obj+=SingleIndexObj(v, &data);
		cumN+=*(d->N+i);
	}
	return obj;
}
void PanelSingleIndex(double *b, double *y, double *x, int *N, int T, int K, int order, int MaxIter, double tol, int warn){
	//number of observations
	int NT=0;
	int k,i,j;
	for (i = 0; i < T; ++i) NT+=*(N+i);
	gsl_vector *v=gsl_vector_alloc(K);
	gsl_vector *s=gsl_vector_alloc(K);
	// prepare for the initial value
	gsl_vector *Y=gsl_vector_alloc(NT);
	gsl_matrix *X=gsl_matrix_alloc(NT,K);
	for (i = 0; i < NT; ++i){
		gsl_vector_set(Y,i,(double)*(y+i));
		for (j = 0; j < K; ++j)
			gsl_matrix_set(X,i,j,*(x+K*i+j));
	}
	demeanMatrixByColumn(X);
	LeastSquare(v,Y,X,warn);
	gsl_vector_scale(v,1/gsl_vector_get(v,0));
	for (k = 1; k < K; ++k)
		gsl_vector_set(s,k,1.2*gsl_vector_get(v,k));
	gsl_vector_set(v,0,1.4*pow(*N,-1.0/5));
	gsl_vector_set(s,0,0.8*gsl_vector_get(v,1));
	gsl_vector_free(Y);
	gsl_matrix_free(X);
	// get ready for the data
	RepeatedDATA_Nonpara data;data.NT=NT; data.T=T; data.N=N; data.K=K; data.y=y; data.x=x; data.order=order;
	// prepare for the minimizer.
	const gsl_multimin_fminimizer_type *minim=gsl_multimin_fminimizer_nmsimplex2;
	gsl_multimin_fminimizer *fmini=gsl_multimin_fminimizer_alloc(minim,K);
	// initializing the minimizer
	gsl_multimin_function Obj;
	Obj.n=K;Obj.f=PanelSingleIndexObj;Obj.params=&data;
	gsl_multimin_fminimizer_set(fmini,&Obj,v,s);
	// iterate
	int iter=0; int status=0; double size;
	do{
		iter++;
		status=gsl_multimin_fminimizer_iterate(fmini);
		if(status>0 && warn==1){
			printf("The Single Index Procedure does not converge....\n");
			break;
		}
		size=gsl_multimin_fminimizer_size(fmini);
		status=gsl_multimin_test_size(size,tol);
	}while(status==GSL_CONTINUE && iter<MaxIter);
	// return result
	for (k=0; k < K; ++k)
		*(b+k)=gsl_vector_get(fmini->x,k);
	// free
	gsl_vector_free(s);
	gsl_vector_free(v);
	gsl_multimin_fminimizer_free(fmini);
}
/*********************Panel Single Index without searching h and with offered initial value**********************/
double SingleIndexObj_noh(const gsl_vector *v, void *params){
	DATA_Nonpara *d=(DATA_Nonpara *)params;
	int i,j;
	double xbar[d->N],G[d->N];
	double obj=0.0;
	double trim=0.005;
	if (*(d->h)<=0)
		return 1e5;
	for (i = 0; i < d->N; ++i){
		*(xbar+i)=*(d->x+(d->K)*i);
		for (j = 1; j < d->K; ++j)
			*(xbar+i)+=gsl_vector_get(v,j-1)**(d->x+(d->K)*i+j);
	}
	KernelSelfRegs(G,d->y,xbar,d->h,d->N,1,1,d->order);
	for (i = 0; i < d->N; ++i){
		// if (isnan(*(G+i))){
		// 	printf("b=%f, xbar=%f, G(%d)=%f\n", gsl_vector_get(v,0),*(xbar+i),i,*(G+i));
		// }
		//if (*(G+i)>1-trim || *(G+i)<trim) continue;
		if (*(G+i)>(1.0-trim)) *(G+i)=1.0-trim;
		if (*(G+i)<trim) *(G+i)=trim;
		if (isnan(*(G+i))) *(G+i)=(*(d->y+i)>0.5)?(1-trim):trim;
		obj+=(*(d->y+i)>0.5?log(*(G+i)):log(1-*(G+i)));
	}
	return -1*obj/d->N;
}
double PanelSingleIndexObj_noh(const gsl_vector *v, void *params){
	RepeatedDATA_Nonpara *d=(RepeatedDATA_Nonpara *)params;
	int i,cumN=0;
	double obj=0.0;
	DATA_Nonpara data;
	for (i = 0; i < d->T; ++i){
		data.N=*(d->N+i);
		data.K=d->K;
		data.x=d->x+cumN*(d->K);
		data.y=d->y+cumN;
		data.h=d->h;
		data.order=d->order;
		obj+=SingleIndexObj_noh(v, &data);
		cumN+=*(d->N+i);
	}
	//printf("obj=%f, b=%f\n", obj, gsl_vector_get(v,0));
	return obj;
}
void PanelSingleIndex_noh(double *b, double *y, double *x, double *b0, double h, int *N, int T, int K, int order, int MaxIter, double tol, int warn){
	//number of observations
	K-=1;
	int k,i,j;
	gsl_vector *v=gsl_vector_alloc(K);
	gsl_vector *s=gsl_vector_alloc(K);
	// prepare for the initial value
	for (i = 0; i < K; ++i){
		gsl_vector_set(v,i,*(b0+i+1));
		gsl_vector_set(s,i,*(b0+i+1)*0.9);
	}
	// get ready for the data
	RepeatedDATA_Nonpara data; data.T=T; data.N=N; data.K=K+1; data.y=y; data.x=x; data.h=&h; data.order=order;
	// prepare for the minimizer.
	const gsl_multimin_fminimizer_type *minim=gsl_multimin_fminimizer_nmsimplex2;
	gsl_multimin_fminimizer *fmini=gsl_multimin_fminimizer_alloc(minim,K);
	// initializing the minimizer
	gsl_multimin_function Obj;
	Obj.n=K;Obj.f=PanelSingleIndexObj_noh;Obj.params=&data;
	gsl_multimin_fminimizer_set(fmini,&Obj,v,s);
	// iterate
	int iter=0; int status=0; double size;
	do{
		iter++;
		status=gsl_multimin_fminimizer_iterate(fmini);
		if(status>0 && warn==1){
			printf("The Single Index Procedure does not converge....\n");
			break;
		}
		size=gsl_multimin_fminimizer_size(fmini);
		status=gsl_multimin_test_size(size,tol);
	}while(status==GSL_CONTINUE && iter<MaxIter);
	// return result
	for (k=0; k < K; ++k)
		*(b+k)=gsl_vector_get(fmini->x,k);
	// free
	gsl_vector_free(s);
	gsl_vector_free(v);
	gsl_multimin_fminimizer_free(fmini);
}
