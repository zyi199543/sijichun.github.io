/*
Author:  Jichun Si
email:   sijichun#gmail.com
Blog:    http://www.sijichun.pro
GitHub:  https://github.com/sijichun
*/

/* Need OpenMP, so add -fopenmp when compiling.
   Need GSL, so add -lgsl -lgslcblas when compiling

Note the order of matrix x should in C style, i.e.
                              [1,2
                               3,4
                               5,6]
should be stored as [1 2 3 4 5 6] but not [1 3 5 2 4 6] like in Matlab!!!
*/
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <omp.h>
#include <gsl/gsl_matrix.h>
#include <gsl/gsl_vector.h>
#include <gsl/gsl_blas.h>
#include <gsl/gsl_multimin.h>
#include <gsl/gsl_statistics.h>
#include <gsl/gsl_linalg.h>
#include "gsl/gsl_eigen.h"
// constants and macros
// constants
#define PI   3.141592653589793
#define PId2 atan(1.0/0.0)
#define INF (-1*log(0))
// Cores for OpenMP
#ifndef CORES
	#define CORES 4
#endif
// sign
#define sgn(d) ((d)<0?-1:1)
// pdf and cdfs
#define normpdf(x) (0.3989422804014327*exp(-0.5*pow((x),2)))
#define logisticcdf(x) (1.0/(1.0+exp(-1.0*(x))))
#define logisticpdf(x) (exp(x)/pow((1.0+exp(x)),2))
// random number
#define RANDU() ((double)rand()/RAND_MAX)
#define EXPRAND() ((double)(-1.0)*log(1.0-((double)rand()/RAND_MAX)))
// seflf-defined
#include "functions.c"
#include "optimization.c"
#include "randnum.c"
#include "econometrics.c"
#include "nonpara.c"
