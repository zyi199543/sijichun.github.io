/*
Author:  Jichun Si
email:   sijichun#gmail.com
Blog:    http://www.sijichun.pro
GitHub:  https://github.com/sijichun
*/

#define BHHH_SUCESS   0
#define BHHH_CONTINUE 1
#define BHHH_FAIL    -1

typedef struct
{
	int N;
	int K; // dimention of parameter
	double tol; // tolerance
	void *data; // the data structure
	gsl_vector *b; // the point vector
	void (*ObjFun)(const gsl_vector*, void*, int, double*, gsl_vector*);// the objective function
	// the next parameters are generated
	double f; // the function value at b
	gsl_vector *s; // the score vector
	gsl_matrix *invH; // the inverse hessian
}BHHH_maximizer;

void BHHH_maximizer_get_scores(BHHH_maximizer *maxi)
{
	int i,j;
	double F[maxi->N];
	gsl_vector *Row[maxi->N];
	for (i = 0; i < maxi->N; ++i)
		*(Row+i)=gsl_vector_alloc(maxi->K);
	#pragma omp parallel for
	for (i = 0; i < maxi->N; ++i)
		maxi->ObjFun(maxi->b, maxi->data, i, F+i, *(Row+i));
	// initialize
	maxi->f=0;
	gsl_vector_set_zero(maxi->s);
	gsl_matrix_set_zero(maxi->invH);
	// compute
	for (i = 0; i < maxi->N; ++i){
		maxi->f+=*(F+i);
		gsl_vector_add(maxi->s,*(Row+i));
/*		for (j = 0; j < maxi->K; ++j)
			printf("%f ", gsl_vector_get(*(Row+i),j));
		printf("\n");*/
		gsl_blas_dsyr(CblasLower,1,*(Row+i),maxi->invH);
	}
	maxi->f/=maxi->N;
	gsl_vector_scale(maxi->s,1.0/maxi->N);
	gsl_matrix_scale(maxi->invH,1.0/maxi->N);
/*	for (i = 0; i < maxi->K; ++i)
	{
		printf("%f ", gsl_vector_get(maxi->s,i));
	}
	printf("\n");
	for (i = 0; i < maxi->K; ++i)
	{
		for (j = 0; j < maxi->K; ++j)
		{
			printf("%f ", gsl_matrix_get(maxi->invH,i,j));
		}
		printf("\n");
	}*/
	// inverse
	int chole=gsl_linalg_cholesky_decomp(maxi->invH);
	gsl_set_error_handler_off();// set the error handler off, if chole==GSL_EDOM, then set maxi->f=-Inf
	if (chole!=GSL_EDOM)
		gsl_linalg_cholesky_invert(maxi->invH);
	else
		maxi->f=-1*INF;
	// free
	for (i = 0; i < maxi->N; ++i)
		gsl_vector_free(*(Row+i));
}

BHHH_maximizer *BHHH_maximizer_alloc(int N, int K, double tol, gsl_vector *v, void *data,
	void (*ObjFun)(const gsl_vector*, void*, int, double *, gsl_vector*)){
	BHHH_maximizer *maxi=malloc(sizeof(BHHH_maximizer));
	maxi->N=N;
	maxi->K=K;
	maxi->tol=tol;
	maxi->data=data;
	maxi->ObjFun=ObjFun;
	// generate variable
	gsl_vector *b=gsl_vector_alloc(K);
	gsl_vector *s=gsl_vector_alloc(K);
	gsl_matrix *H=gsl_matrix_alloc(K,K);
	maxi->b=b; maxi->s=s; maxi->invH=H;
	gsl_vector_memcpy(maxi->b,v);
	BHHH_maximizer_get_scores(maxi);
	return maxi;
}
void BHHH_maximizer_free(BHHH_maximizer *maxi){
	gsl_vector_free(maxi->b);
	gsl_vector_free(maxi->s);
	gsl_matrix_free(maxi->invH);
	free(maxi);
}
void BHHH_maximizer_memcpy(BHHH_maximizer *dest, BHHH_maximizer *from){
	dest->N=from->N;
	dest->K=from->K;
	dest->tol=from->tol;
	dest->data=from->data;
	dest->ObjFun=from->ObjFun;
	dest->f=from->f;
	gsl_vector_memcpy(dest->b,from->b);
	gsl_vector_memcpy(dest->s,from->s);
	gsl_matrix_memcpy(dest->invH,from->invH);
}
void BHHH_maximizer_reset(BHHH_maximizer *maxi, gsl_vector *v){
	gsl_vector_memcpy(maxi->b,v);
	BHHH_maximizer_get_scores(maxi);
}
int BHHH_iterate(BHHH_maximizer *s){
	int i;
	//compute the next parameter
	gsl_vector *w=gsl_vector_alloc(s->K);
	// b(w)=invH*s+b
	gsl_vector_memcpy(w,s->b);
	gsl_blas_dgemv(CblasNoTrans,1,s->invH,s->s,1,w);
	BHHH_maximizer *sp=BHHH_maximizer_alloc(s->N,s->K,s->tol,w,s->data,s->ObjFun);
	gsl_vector_free(w);
	// if objective function is not defined or the Hessian is not positive-definite
	if (isinf(s->f)!=0 || isnan(s->f)==1)
	{
		BHHH_maximizer_free(sp);
		return BHHH_FAIL;
	}
	// positive-definite?
	int pd=1;
	gsl_eigen_symm_workspace *ws=gsl_eigen_symm_alloc(s->K);
	gsl_matrix *Hp=gsl_matrix_alloc(s->K,s->K);
	gsl_matrix_memcpy(Hp,s->invH);
	gsl_vector *eigva=gsl_vector_alloc(s->K);
	gsl_eigen_symm(Hp,eigva,ws);
	for (i = 0; i < s->K; ++i)
		if (gsl_vector_get(eigva,i)<=0)
			pd=0;
	gsl_vector_free(eigva);
	gsl_matrix_free(Hp);
	gsl_eigen_symm_free(ws);
	// convergence?
	if (((sp->f)-(s->f)<s->tol || (s->f)-(sp->f)<s->tol) && gsl_blas_dasum(sp->s)<(s->tol*s->N))
	{
		if (pd==1)
		{
			BHHH_maximizer_memcpy(s,sp);
			BHHH_maximizer_free(sp);
			return BHHH_SUCESS;
		}else{
			BHHH_maximizer_free(sp);
			return BHHH_FAIL;
		}
	}else{
		BHHH_maximizer_memcpy(s,sp);
		BHHH_maximizer_free(sp);
		return BHHH_CONTINUE;
	}
}


/* One-dimension grid search for the minimum
LB:   lower bound
UB:   upper bound
 N:   grid number
 f:   objective function, with double objfun(double, void *)
it:   number of iterations
*/

double gridSearch1(double LB, double UB, int N, int it, void *data, double (*f)(double, void *)){
	int i,t;
	double lb=(LB<UB)?LB:UB,ub=(UB>LB)?UB:LB,step;
	double linespace[N];
	double minf=-1*log(0),minx=lb,maxx=ub,lastminx=lb,lastmaxx=ub,obj;
	for (t = 0; t < it; ++t){
		//generate line space
		step=(ub-lb)/(N-1);
		for (i = 0; i < N; ++i) linespace[i]=lb+step*i;
		//search
		for (i = 0; i < N; ++i){
			obj=f(linespace[i],data);
			if (obj<minf){
				minf=obj;
				minx=linespace[i];
				maxx=minx;
			}else if (obj==minf) maxx=linespace[i];
		}
		// check if converge
		if (minx==lastminx && maxx==lastmaxx) break;
		//update bounds
		lastminx=minx;
		lastmaxx=maxx;
		lb=minx-2*step;
		ub=maxx+2*step;
	}
	return (minx+maxx)/2;
}
/* One-dimension grid search for the minimum
opt:   the returned optimal x.
  K:   the dimension of x
 LB:   lower bounds
 UB:   upper bounds
  N:   grid number
 it:   number of iterations
  f:   objective function, with double objfun(double *, void *)
*/
double gridSearch(double *opt, int K, double *UB, double *LB, int N, int it, void *data, double (*f)(double *, void *)){
	int i,t,k;
	double lb[K], ub[K], step[K];
	int index[K],min_index[K],jinwei=0, cend;
	double  linespace[K][N], minf=-1*log(0),obj,x[K];
	for (k = 0; k < K; ++k){
		*(lb+k)=(*(LB+k)<*(UB+k))?*(LB+k):*(UB+k);
		*(ub+k)=(*(UB+k)>*(LB+k))?*(UB+k):*(LB+k);
	}
	for (t =0; t < it; ++t){
		// generate line space
		for (k = 0; k < K; ++k) step[k]=(ub[k]-lb[k])/(N-1);
		for (k = 0; k < K; ++k)
			for (i = 0; i < N; ++i)
				linespace[k][i]=lb[k]+step[k]*i;
		for (k = 0; k < K; ++k) index[k]=0;
		while (1){
			// compute f and compare
			for (k = 0; k < K; ++k){
				x[k]=linespace[k][index[k]];
			}
			obj=f(x,data);
			if (obj<minf){
				minf=obj;
				for (k = 0; k < K; ++k) min_index[k]=index[k];
			}
			// end?
			cend=0;
			for (k = 0; k < K; ++k){
				if (index[k]==(N-1)){
					++cend;
				}else{
					break;
				}
			}
			if (cend==K) break;
			// iterate
			for (k = K-1; k >= 0; --k){
				if (jinwei==0){
					if (index[k]<(N-1)){
						++index[k];
						break;
					}else{
						index[k]=0;
						if (k!=0){
							++index[k-1];
							jinwei=1;
						}
					}
				}else{
					if (index[k]<N){
						jinwei=0;
						break;
					}else{
						index[k]=0;
						if (k!=0){
							++index[k-1];
							jinwei=1;
						}
					}
				}
			}
			// update lb and ub
			for (k = 0; k < K; ++k){
				*(lb+k)=linespace[k][min_index[k]]-step[k];
				*(ub+k)=linespace[k][min_index[k]]+step[k];
			}
		}
	}
	//return
	for (k = 0; k < K; ++k) *(opt+k)=linespace[k][min_index[k]];
}

void generateParametersSpace(int *B, int K, int N, int NK){
	int i,k;
	for (i = 0; i < K; ++i) *(B+i)=0;
	i=1;
	while (i<NK){
		*(B+i*K+K-1)=*(B+(i-1)*K+K-1)+1;
		for (k=K-1; k >0; --k){
			if (*(B+i*K+k)==N){
				*(B+i*K+k)=0;
				*(B+i*K+k-1)=*(B+(i-1)*K+k-1)+1;
			}else{
				*(B+i*K+k-1)=*(B+(i-1)*K+k-1);
			}
		}
		++i;
	}
}
void gridSearch_parallel(double *opt, int K, double *UB, double *LB, int N, int it, void *data, double (*f)(double *, void *)){
	int i,t,k,min_index;
	double lb[K], ub[K], step[K];
	double  linespace[K][N],minf;
	for (k = 0; k < K; ++k){
		*(lb+k)=(*(LB+k)<*(UB+k))?*(LB+k):*(UB+k);
		*(ub+k)=(*(UB+k)>*(LB+k))?*(UB+k):*(LB+k);
	}
	// generate B
	int NK=1;
	for (i = 0; i < K; ++i)
		NK*=N;
	int B[NK*K];
	double obj[NK], X[NK*K];
	generateParametersSpace(B,K,N,NK);
	for (t =0; t < it; ++t){
		minf=-1*log(0);
		min_index=0;
		// generate line space
		for (k = 0; k < K; ++k) step[k]=(ub[k]-lb[k])/(N-1);
		for (k = 0; k < K; ++k)
			for (i = 0; i < N; ++i)
				linespace[k][i]=lb[k]+step[k]*i;
		// name X
		for (i = 0; i < NK; ++i)
			for (k = 0; k < K; ++k)
				*(X+i*K+k)=linespace[k][*(B+i*K+k)];
		// compute the obj function
		#pragma omp parallel for
		for (i = 0; i < NK; ++i)
			*(obj+i)=f(X+i*K,data);
		// find the minimum
		for (i = 0; i < NK; ++i){
			if (*(obj+i)<minf){
				minf=*(obj+i);
				min_index=i;
			}
		}
		// update lb and ub
		for (k = 0; k < K; ++k){
			*(lb+k)=*(X+min_index*K+k)-step[k];
			*(ub+k)=*(X+min_index*K+k)+step[k];
		}
	}
	//return
	for (k = 0; k < K; ++k) *(opt+k)=*(X+min_index*K+k);
}