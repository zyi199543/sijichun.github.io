/*
Author:  Jichun Si
email:   sijichun#gmail.com
Blog:    http://www.sijichun.pro
GitHub:  https://github.com/sijichun
*/

/*
 Generate standard normal random numbers.
 output: the output array.
 n:      the dimension.
 
 If you want to generate a matrix, just set n=m*k.
 */
void randn(double *output, int n)
{
  int i;
  double y1,y2;
  for (i=0;i<n;i++){
    for (;;){
      y1=EXPRAND();
      y2=EXPRAND();
      if (y2>(pow(1-y1,2)/2)) break;
    }
    *(output+i)=y1*((RANDU()<0.5)?1:-1);
  }
}

/*
 Generate uniform random numbers.
 output: the output array.
 n:      the dimension.
 
 If you want to generate a matrix, just set n=m*k.
 */
void randu(double *output, int n)
{
  int i;
  for (i=0;i<n;i++)
    *(output+i)=RANDU();
}
/*
 Generate exponential random numbers.
 output: the output array.
 n:      the dimension.
 
 If you want to generate a matrix, just set n=m*k.
 */
void rande(double *output, int n)
{
  int i;
  for (i=0;i<n;i++)
    *(output+i)=EXPRAND();
}
/*
 Generate logistic random numbers.
 output: the output array.
 n:      the dimension.
 
 If you want to generate a matrix, just set n=m*k.
 */
void randl(double *output, int n)
{
  int i;
  double u;
  for (i=0;i<n;i++){
    u=RANDU();
    *(output+i)=log(1.0/(1-u)-1);
  }
}

/*
 Generate Possion random numbers.
 output: the output array.
 n:      the dimension.
 lambda: the mean of the random numbers
 
 If you want to generate a matrix, just set n=m*k.
 */
void randp(int *output,int n, double lambda){
	int i,N;
  double p,c=exp(-1*lambda);
	for (i=0;i<n;++i){
    // initialize
    p=1;
    N=0;
    for (;;){
      N++;
      p*=(RANDU());
      if (p<c) break;
    }
	  *(output+i)=N-1;
	}
}

/*
 Generate Pareto random numbers.
 output: the output array.
 n:      the dimension.
 miu, sigma, gamma, alpha: see wikipedia, Pareto distribution: https://en.wikipedia.org/wiki/Pareto_distribution
 
 If you want to generate a matrix, just set n=m*k.
 */
void randpareto(double *output, int N, double miu, double sigma, double gamma, double alpha){
  double u;
  int i;
  if (gamma==1.0){
      for (i = 0; i < N; ++i){
      u=RANDU();
      if (alpha==1.0) *(output+i)=miu+sigma*(1/u-1);
      else *(output+i)=miu+sigma*(pow(u,-1/alpha)-1);
    }
  }else{
    for (i = 0; i < N; ++i){
      u=RANDU();
      if (alpha==1.0) *(output+i)=miu+sigma*pow(1/u-1,gamma);
      else *(output+i)=miu+sigma*pow(pow(u,-1/alpha)-1,gamma);
    }
  }
}
