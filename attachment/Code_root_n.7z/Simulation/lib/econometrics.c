/*
Author:  Jichun Si
email:   sijichun#gmail.com
Blog:    http://www.sijichun.pro
GitHub:  https://github.com/sijichun
*/

/*
The result structure.
****** DO NOT FOGET to FREE (b yhat resid cov)_vec when this strucure is useless!*********
*/

typedef struct
{
	int N;
	int K;
	// the coefficients
	double *b;
	gsl_vector *b_vec;
	// the fitted value
	double *yhat;
	gsl_vector *yhat_vec;
	// the residuals
	double *resid;
	gsl_vector *resid_vec;
	// the covariance matrix
	double *cov;
	gsl_matrix *cov_mat;
	// the t-value and p-value
	double *t;
	double *p;
	// R-square
	double Rsqare;
	double SST;
	double SSR;
	double SSE;
}Result_OLS;

Result_OLS *Result_OLS_alloc(){
	return (Result_OLS *)malloc(sizeof(Result_OLS));
}
void Result_OLS_free(Result_OLS *ro){
	gsl_vector_free(ro->b_vec);
	gsl_vector_free(ro->yhat_vec);
	gsl_vector_free(ro->resid_vec);
	gsl_matrix_free(ro->cov_mat);
	free(ro->t);
	free(ro->p);
	free(ro);
}
/*
The least-square computation
	b:     the return parameter,       vector
	y:     the dependent variable,     vector
	x:     the control variable,       matrix
	warn:  need warning message?
		         1=need
		         0=not.
*/
int LeastSquare(gsl_vector *b, const gsl_vector *y, const gsl_matrix *x, int warn){
	int N=x->size1, K=x->size2;
	if (K>N){
		if (warn==1)
			printf("No enough observations!\n");
		return -1;
	}
	int i,j,rv=0;
	double ConditionNumber;
	gsl_matrix *V=gsl_matrix_alloc(K,K);
	gsl_vector *S=gsl_vector_alloc(K);
	gsl_vector *w=gsl_vector_alloc(K);
	gsl_matrix *xx=gsl_matrix_calloc(K,K);
	gsl_vector *xy=gsl_vector_calloc(K);
	// compute x'x
	gsl_blas_dsyrk(CblasUpper,CblasTrans,1.0,x,0.0,xx);
	for (i = 0; i < K; ++i)
		for (j = 0; j < i; ++j)
			gsl_matrix_set(xx,i,j,gsl_matrix_get(xx,j,i));
	// compute x'y
	gsl_blas_dgemv(CblasTrans,1.0,x,y,0.0,xy);
	// Single Value Decomposition
	gsl_linalg_SV_decomp(xx,V,S,w);
	if (gsl_vector_get(S,K-1)<1e-10){
		if (warn==1)
			printf("Matrix is singular, please check the rank condition.\n");
		rv=-2;
	}else{
		ConditionNumber=gsl_vector_get(S,0)/gsl_vector_get(S,K-1);
		if (warn==1 && ConditionNumber > 1000)
			printf("The condition number=%f, matrix is near singular!\n", ConditionNumber);
		gsl_linalg_SV_solve(xx,V,S,xy,b);
		rv=1;
	}
	// free
	gsl_matrix_free(xx);
	gsl_vector_free(xy);
	gsl_vector_free(S);
	gsl_vector_free(w);
	gsl_matrix_free(V);
	return rv;
}

void OLS(Result_OLS *result,const double *y, const double *x,int N, int K, int insert_cons, int robust, int warn){
	if(insert_cons==1) K++;
	gsl_vector *Y=gsl_vector_alloc(N);
	gsl_matrix *X=gsl_matrix_alloc(N,K);
	gsl_vector *b=gsl_vector_alloc(K);
	gsl_vector *Yhat=gsl_vector_calloc(N);
	gsl_vector *Residuals=gsl_vector_alloc(N);
	gsl_matrix *cov=gsl_matrix_calloc(K,K);
	double *t=(double *)malloc(K*sizeof(int));
	double *p=(double *)malloc(K*sizeof(int));
	int i,j;
	// initialize
	for(i=0;i<N;++i){
		gsl_vector_set(Y,i,*(y+i));
		if (insert_cons==0){
			for(j=0;j<K;++j)
				gsl_matrix_set(X,i,j,*(x+i*K+j));
		}else{
			gsl_matrix_set(X,i,K-1,1.0);
			for (j=0;j<K-1;++j)
				gsl_matrix_set(X,i,j,*(x+i*(K-1)+j));
		}
	}
	// least square estimation
	LeastSquare(b,Y,X,warn);
	// compute the fitted value
	gsl_blas_dgemv(CblasNoTrans,1.0,X,b,0.0,Yhat);
	// compute the residuals
	gsl_vector_memcpy(Residuals,Y);
	gsl_vector_sub(Residuals,Yhat);
	// compute the variance
	// return result
	result->N=N;
	result->K=K;
	result->b=b->data;
	result->b_vec=b;
	result->yhat=Yhat->data;
	result->yhat_vec=Yhat;
	result->resid=Residuals->data;
	result->resid_vec=Residuals;
	result->cov=cov->data;
	result->cov_mat=cov;
	//free
	gsl_vector_free(Y);
	gsl_matrix_free(X);
}

/*********************Logit and Probit**********************/
typedef struct{
int N;
int K;
int PL;
int *d;
double *x;
}DATA_PLogit;

double PLogit_f(const gsl_vector *v, void *params){
	DATA_PLogit *data=(DATA_PLogit *)params;
	int i,j;
	double xb,G,obj=0;
	// xb
	for (i = 0; i < data->N; ++i){
		xb=0;
		for (j = 0; j < data->K; ++j)
			xb+=gsl_vector_get(v,j)*(*(data->x+data->K*i+j));
		G=((data->PL)==0)?logisticcdf(xb):normcdf(xb);
		G=(G>1e-7?G:1e-7); G=(G<(1-1e-7)?G:1-1e-7);
		obj+=((*(data->d+i)==1)?log(G):log(1.0-G));
	}
	return -1*obj/data->N;
}

void PLogit_df(const gsl_vector *v, void *params, gsl_vector *df){
	DATA_PLogit *data=(DATA_PLogit *)params;
	int i,j;
	// xb
	double xb,g,G,s[data->K],scale;
	for (i = 0; i < data->K; ++i)
		*(s+i)=0;
	for (i = 0; i < data->N; ++i){
		xb=0;
		for (j = 0; j < data->K; ++j)
			xb+=gsl_vector_get(v,j)*(*(data->x+data->K*i+j));
		G=((data->PL)==0)?logisticcdf(xb):normcdf(xb);
		G=(G>1e-7?G:1e-7); G=(G<(1-1e-7)?G:1-1e-7);
		g=((data->PL)==0)?logisticpdf(xb):normpdf(xb);
		scale=g*((double)*(data->d+i)-G)/(G*(1.0-G));
		for (j = 0; j < data->K; ++j)
			*(s+j)+=(scale*(*(data->x+data->K*i+j)));
	}
	for (i = 0; i < data->K; ++i)
		gsl_vector_set(df,i,-1*(*(s+i))/data->N);
}
void PLogit_fdf(const gsl_vector *v, void *params, double *f, gsl_vector *df){
	DATA_PLogit *data=(DATA_PLogit *)params;
	int i,j;
	// xb
	double xb,g,G,s[data->K],scale,obj=0;
	for (i = 0; i < data->K; ++i)
		*(s+i)=0;
	for (i = 0; i < data->N; ++i){
		xb=0;
		for (j = 0; j < data->K; ++j)
			xb+=gsl_vector_get(v,j)*(*(data->x+data->K*i+j));
		G=((data->PL)==0)?logisticcdf(xb):normcdf(xb);
		G=(G>1e-7?G:1e-7); G=(G<(1-1e-7)?G:1-1e-7);
		g=((data->PL)==0)?logisticpdf(xb):normpdf(xb);
		obj+=((*(data->d+i)==1)?log(G):log(1.0-G));
		scale=g*((double)*(data->d+i)-G)/(G*(1.0-G));
		for (j = 0; j < data->K; ++j)
			*(s+j)+=(scale*(*(data->x+data->K*i+j)));
	}
	for (i = 0; i < data->K; ++i)
		gsl_vector_set(df,i,-1*(*(s+i))/data->N);
	*f=-1*obj/data->N;
}
/*
The Logit/Probit estimation.
	b:        the estimation result
	d:        the LHS variable
	x:        the RHS variable
	N:        the number of observations
	K:        the number of columns in x
	PL:       Probit or Logit? 0=Logit, 1=Probit
	MaxIter:  the maximum iterations
	tol:      the tolerence, maybe 1e-5
	warn:     print the warning message?
*/
void PLogit(double *b, int *d, double *x, int N, int K, int PL, int MaxIter, double tol, int warn){
	DATA_PLogit data; data.N=N; data.K=K; data.PL=PL; data.d=d; data.x=x;
	int i,j;
	gsl_vector *v=gsl_vector_alloc(K);
	// initial value
	gsl_vector *Y=gsl_vector_alloc(N);
	gsl_matrix *X=gsl_matrix_alloc(N,K);
	for (i = 0; i < N; ++i){
		gsl_vector_set(Y,i,(double)*(d+i));
		for (j = 0; j < K; ++j)
			gsl_matrix_set(X,i,j,*(x+K*i+j));
	}
	LeastSquare(v, Y, X, 0);
	gsl_vector_free(Y);
	gsl_matrix_free(X);
	gsl_vector *vv=gsl_vector_alloc(K);
	double scaler[7]={0.25,0.5,1,2,4,8,16}, best_scale=0, f, best_f=-1*log(0);
	for (i = 0; i < 7; ++i){
		gsl_vector_memcpy(vv,v);
		gsl_vector_scale(vv,scaler[i]);
		f=PLogit_f(vv, &data);
		if (f<best_f){
			best_f=f;
			best_scale=scaler[i];
		}
	}
	gsl_vector_scale(v,best_scale);
	gsl_vector_free(vv);
	// maximize
	size_t iter=0;
	int status;
	const gsl_multimin_fdfminimizer_type *T;
	gsl_multimin_fdfminimizer *minimizer;
	gsl_multimin_function_fdf min_func;
	min_func.n=K;
	min_func.f=PLogit_f;
	min_func.df=PLogit_df;
	min_func.fdf=PLogit_fdf;
	min_func.params=&data;
	// algorithm
	T=gsl_multimin_fdfminimizer_vector_bfgs2;
	// T=gsl_multimin_fdfminimizer_conjugate_fr;
	minimizer=gsl_multimin_fdfminimizer_alloc(T,K);
	gsl_multimin_fdfminimizer_set(minimizer, &min_func, v, 0.1, 0.01);
	do{
		iter++;
		status=gsl_multimin_fdfminimizer_iterate(minimizer);
		if (status)
			break;
		status=gsl_multimin_test_gradient(minimizer->gradient, tol);
		if (status==GSL_SUCCESS)
			break;
	}while(status==GSL_CONTINUE && iter<MaxIter);
	// compute variance
	gsl_vector *beta=gsl_multimin_fdfminimizer_x(minimizer);
	for (i = 0; i < K; ++i)
		*(b+i)=gsl_vector_get(beta,i);
	// free
	gsl_multimin_fdfminimizer_free(minimizer);
	gsl_vector_free(v);
}