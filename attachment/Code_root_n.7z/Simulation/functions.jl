## data type
type Data
	N::Int64
	d1
	d2
	x11
	x12
	x21
	x22
end
## data generating process
function DGP(N::Int,c::Real)
	x11=randn(N)-1
	x12=randn(N)-1
	x21=randn(N)-1
	# x22=randn(N)*2-1
	x22=rand(N)*2-1
	x2bar=c*(x12+x22)/2
	# yita=x2bar+4*rand(N)-2
	yita=x2bar+randn(N)*1.414
	u1=-1*log(1./rand(N)-1)/(pi/sqrt(3))
	u2=-1*log(1./rand(N)-1)/(pi/sqrt(3))
	d1=(1*x11-x12-yita+u1).>=0
	d2=(1*x21-x22-yita+u2).>=0
	# u1=-1*log(1./rand(N)-1)
	# u2=-1*log(1./rand(N)-1)
	# d1=(1*x11-x12+u1).>=0
	# d2=(1*x21-x22+u2).>=0
	return Data(N,d1,d2,x11,x12,x21,x22)
end

function CrossValid_boots(Y,X;LOO=0,warn=1,MaxIter=1000,tol=1e-3)
	N=length(Y)
	h=Array(Cdouble,4)
	yhat=Array(Cdouble,N)
	y=convert(Array{Cdouble},Y)
	x=convert(Array{Cdouble},vec(X'))
	ccall((:CrossValid_boots,"./libbootstrap.o"),Void,
		(Ptr{Cdouble},Ptr{Cdouble},Ptr{Cdouble},Ptr{Cdouble},Int64,Int64,Float64,Int64,Int64),
		h,yhat,y,x,N,MaxIter,tol,LOO,warn)
	return h,yhat
end

function estimate_h(data,h1,h2;order=2,trim=0.025,L=3::Int64)
	N=data.N
	H1=convert(Array{Cdouble},h1)
	H2=convert(Array{Cdouble},h2)
	d1=convert(Array{Cdouble},data.d1)
	d2=convert(Array{Cdouble},data.d2)
	x=convert(Array{Cdouble},vec([data.x11 data.x12 data.x21 data.x22]'))
	b=ccall((:estimate_h,"./libbootstrap.o"),Cdouble,
		(Int64,Ptr{Cdouble},Ptr{Cdouble},Ptr{Cdouble},Ptr{Cdouble},Ptr{Cdouble},Int64,Cdouble,Int64),
		N,H1,H2,d1,d2,x,L,trim,order)
	return b
end

function estimate_CV(data;order=2,trim=0.025,L=3::Int64,MaxIter=500,tol=0.05,warn=0)
	N=data.N
	h=Array(Cdouble,1)
	d1=convert(Array{Cdouble},data.d1)
	d2=convert(Array{Cdouble},data.d2)
	x=convert(Array{Cdouble},vec([data.x11 data.x12 data.x21 data.x22]'))
	b=ccall((:estimate_cv,"./libbootstrap.o"),Cdouble,
		(Ptr{Cdouble},Ptr{Cdouble},Ptr{Cdouble},Ptr{Cdouble},Int64,Int64,Cdouble,Int64,Int64,Cdouble,Int64),
		h,d1,d2,x,N,L,trim,order,MaxIter,tol,warn)
	return b,h[1]
end

function estimate_CV2(data;order=2,trim=0.025,L=3::Int64,MaxIter=500,tol=0.05,warn=0)
	N=data.N
	h=Array(Cdouble,2)
	d1=convert(Array{Cdouble},data.d1)
	d2=convert(Array{Cdouble},data.d2)
	x=convert(Array{Cdouble},vec([data.x11 data.x12 data.x21 data.x22]'))
	b=ccall((:estimate_cv2,"./libbootstrap.o"),Cdouble,
		(Ptr{Cdouble},Ptr{Cdouble},Ptr{Cdouble},Ptr{Cdouble},Int64,Int64,Cdouble,Int64,Int64,Cdouble,Int64),
		h,d1,d2,x,N,L,trim,order,MaxIter,tol,warn)
	return b,h
end

function smoothMS(data;h=1,order=-1,MaxIter=500,tol=0.001,warn=0)
	N=data.N
	d=data.d2-data.d1;
	d=convert(Array{Cint},d)
	dx=[data.x21 data.x22]-[data.x11 data.x12]
	dx=convert(Array{Cdouble},vec(dx'))
	b=ccall((:SmoothedMaximumScore,"./libbootstrap.o"),Cdouble,
		(Ptr{Cint},Ptr{Cdouble},Int64,Int64,Cdouble,Int64,Cdouble,Int64),
		d,dx,N,order,h,MaxIter,tol,warn)
	return b
end
function smoothMS_ls(data;h=1,order=-1)
	N=data.N
	d=data.d2-data.d1;
	d=convert(Array{Cint},d)
	dx=[data.x21 data.x22]-[data.x11 data.x12]
	dx=convert(Array{Cdouble},vec(dx'))
	b=ccall((:SmoothedMaximumScore_ls,"./libbootstrap.o"),Cdouble,
		(Ptr{Cint},Ptr{Cdouble},Int64,Int64,Cdouble),
		d,dx,N,order,h)
	return b
end

function conditionalLogit(d1,d2,x1,x2,N;warn=0,tol=1e-4,MaxIter=200)
	nd1=convert(Array{Cint},d1)
	nd2=convert(Array{Cint},d2)
	dx=x2-x1;
	dx=convert(Array{Cdouble},vec(dx'))
	b=Array(Cdouble,2)
	ccall((:ConditionalLogit,"./libbootstrap.o"),Void,
		(Ptr{Cdouble},Ptr{Cint},Ptr{Cint},Ptr{Cdouble},Int64,Int64,Float64,Int64),
		b,nd1,nd2,dx,N,warn,tol,MaxIter)
	return b
end
