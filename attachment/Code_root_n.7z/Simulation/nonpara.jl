#!/usr/bin/julia
function CrossValidDesnsity(x; LOO=0)
	N=length(x)
	fx=Array(Cdouble, N)
	X=convert(Array{Cdouble}, x)
	h=ccall((:CrossValidDesnsity,"/home/aragorn/Working/lib/libsjceconometric.o"),Cdouble,
		(Ptr{Cdouble},Ptr{Cdouble},Int64,Int64),
		fx, X, N, LOO)
	return fx,h
end
function KernleDensity(x,xd; h=-1.0, max_iter=100, warn=0)
	N=length(x)
	Nd=length(xd)
	fx=Array(Cdouble, Nd)
	X=convert(Array{Cdouble},x)
	Xd=convert(Array{Cdouble},xd)
	if h>0
		ccall((:CrossValidDesnsity,"/home/aragorn/Working/lib/libsjceconometric.o"),Void,
			(Ptr{Cdouble},Ptr{Cdouble},Int64,Ptr{Cdouble},Int64,Cdouble,Int64),
			fx, X, N, Xd, Nd, h, 2)
	else
		ff,h=CrossValidDesnsity(x,max_iter=max_iter)
		ccall((:CrossValidDesnsity,"/home/aragorn/Working/lib/libsjceconometric.o"),Void,
			(Ptr{Cdouble},Ptr{Cdouble},Int64,Ptr{Cdouble},Int64,Cdouble,Int64),
			fx, X, N, Xd, Nd, h, 2)
	end
	return fx,h
end
function KernelSelfReg(Y,X,h;LOO=0,order=2)
	K=size(X,2)
	N=length(Y)
	yhat=Array(Cdouble,N)
	y=convert(Array{Cdouble},Y)
	x=convert(Array{Cdouble},vec(X'))
	ccall((:KernelSelfRegs,"/home/aragorn/Working/lib/libsjceconometric.o"),Void,
		(Ptr{Cdouble},Ptr{Cdouble},Ptr{Cdouble},Ptr{Cdouble},Int64,Int64,Int64,Int64),
		yhat,y,x,h,N,K,LOO,order)
	return yhat
end
function CrossValid(Y,X;order=2,LOO=0,warn=1,MaxIter=1000,tol=1e-4)
	K=size(X,2)
	N=length(Y)
	h=Array(Cdouble,K)
	yhat=Array(Cdouble,N)
	y=convert(Array{Cdouble},Y)
	x=convert(Array{Cdouble},vec(X'))
	ccall((:CrossValid,"/home/aragorn/Working/lib/libsjceconometric.o"),Void,
		(Ptr{Cdouble},Ptr{Cdouble},Ptr{Cdouble},Ptr{Cdouble},Int64,Int64,Int64,Int64,Float64,Int64,Int64),
		h,yhat,y,x,N,K,order,MaxIter,tol,LOO,warn)
	return h,yhat
end
function Logit(Y,X;warn=1,MaxIter=5000,tol=1e-5)
	N=length(Y)
	K=size(X,2)
	b=Array(Cdouble,K)
	Y=round(Int32,Y)
	result=ccall((:PLogit,"/home/aragorn/Working/lib/libsjceconometric.o"),Void,
		(Ptr{Cdouble},Ptr{Int32},Ptr{Cdouble},Int64,Int64,Int64,Int64,Float64,Int64),
		b,Y,vec(X'),N,K,0,MaxIter,tol,warn)
	xbar=X*b
	phat=1./(1+exp(-1*xbar))
	return b,phat
end
function Probit(Y,X;warn=1,MaxIter=5000,tol=1e-5)
	N=length(Y)
	K=size(X,2)
	b=Array(Cdouble,K)
	Y=round(Int32,Y)
	result=ccall((:PLogit,"/home/aragorn/Working/lib/libsjceconometric.o"),Void,
		(Ptr{Cdouble},Ptr{Int32},Ptr{Cdouble},Int64,Int64,Int64,Int64,Float64,Int64),
		b,Y,vec(X'),N,K,1,MaxIter,tol,warn)
	return b
end
function Hobbit(Y,X;order=2,warn=1,MaxIter=1000,tol=1e-4)
	N=length(Y)
	K=size(X,2)
	b=Array(Cdouble,K)
	Y=float(Y)
	result=ccall((:SingleIndex,"/home/aragorn/Working/lib/libsjceconometric.o"),Void,
		(Ptr{Cdouble},Ptr{Cdouble},Ptr{Cdouble},Int64,Int64,Int64,Int64,Float64,Int64),
		b,Y,vec(X'),N,K,order,MaxIter,tol,warn)
	h=b[1]
	b[1]=1
	return b,h
end
function PanelHobbit(Y,X,N,T;order=2,warn=1,MaxIter=1000,tol=1e-4)
	## note N is a vector
	if length(N)!=T
		return NaN,NaN
	end
	if size(X,1)!=sum(N)
		return NaN,NaN
	end
	if length(Y)!=sum(N)
		return NaN,NaN
	end
	N=convert(Array{Int32},N)
	K=size(X,2)
	b=Array(Cdouble,K)
	Y=float(Y)
	result=ccall((:PanelSingleIndex,"/home/aragorn/Working/lib/libsjceconometric.o"),Void,
		(Ptr{Cdouble},Ptr{Cdouble},Ptr{Cdouble},Ptr{Cint},Int64,Int64,Int64,Int64,Float64,Int64),
		b,Y,vec(X'),N,T,K,order,MaxIter,tol,warn)
	h=b[1]
	b[1]=1
	return b,h
end
function PanelHobbit_Noh(Y,X,N,T,h,b0;order=2,warn=1,MaxIter=1000,tol=1e-4)
	## note N is a vector
	if length(N)!=T
		return NaN,NaN
	end
	if size(X,1)!=sum(N)
		return NaN,NaN
	end
	if length(Y)!=sum(N)
		return NaN,NaN
	end
	N=convert(Array{Int32},N)
	K=size(X,2)
	b=Array(Cdouble,K-1)
	Y=float(Y)
	result=ccall((:PanelSingleIndex_noh,"/home/aragorn/Working/lib/libsjceconometric.o"),Void,
		(Ptr{Cdouble},Ptr{Cdouble},Ptr{Cdouble},Ptr{Cdouble},Float64,Ptr{Cint},Int64,Int64,Int64,Int64,Float64,Int64),
		b,Y,vec(X'),b0,h,N,T,K,order,MaxIter,tol,warn)
	return b
end