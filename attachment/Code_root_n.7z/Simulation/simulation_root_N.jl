#!/usr/bin/julia
## package
include("/home/aragorn/Working/lib/julia/nonpara.jl")
include("functions.jl")

function DGP1(N::Int,truev::Real,var::Real)
	x11=randn(N)-1
	x12=randn(N)-1
	x21=randn(N)-1
	x22=rand(N)*2-1
	x2bar=(x12+x22)/2
	yita=x2bar+4*rand(N)-0.75
	u1=-1*log(1./rand(N)-1)/(pi/sqrt(3))
	u2=-1*log(1./rand(N)-1)/(pi/sqrt(3))*var
	d1=(1*x11-truev*x12+yita+u1).>=0
	d2=(1*x21-truev*x22+yita+u2).>=0
	return Data(N,d1,d2,x11,x12,x21,x22)
end
## parameters
truev=2
var=3
## Monte carlo
srand(2010210095)
N=300
iter=500
order=2
## init
BETA=zeros(iter,9)
bb=zeros(iter,2)
####### under the null ############
for i=1:iter
	data=DGP1(N,truev,sqrt(var))
	b=conditionalLogit(data.d1,data.d2,[data.x11 data.x12],[data.x21 data.x22],N)
	bb[i,:]=b
	BETA[i,1]=b[2]/b[1]
	BETA[i,2]=smoothMS_ls(data)
	BETA[i,3]=smoothMS_ls(data,order=2,h=0.5)
	BETA[i,4]=smoothMS_ls(data,order=2,h=1.5)
	BETA[i,5]=smoothMS_ls(data,order=2,h=3)
	BETA[i,6]=smoothMS_ls(data,order=4,h=0.5)
	BETA[i,7]=smoothMS_ls(data,order=4,h=1.5)
	BETA[i,8]=smoothMS_ls(data,order=4,h=3)
	 beta,h1 =estimate_CV(data,order=order)
	BETA[i,9]=beta[1]
	println("$(round(mean(BETA[1:i,:],1)*1000)/1000), std=$(round(std(BETA[1:i,:],1)*1000)/1000), iter=$(i)")
end
bias=mean(BETA,1)
sd=std(BETA,1)
mse=sqrt(mean((BETA+truev).^2,1))
RESULTS=[bias;sd;mse]'
println("Results:")
println(RESULTS)