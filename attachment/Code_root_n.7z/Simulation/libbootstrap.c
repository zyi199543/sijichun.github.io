#include "/home/aragorn/Working/lib/src/libsjceconometric.c"

void DGP(double *d1, double *d2, double *x, int N, double c){
	int i;
	double x11[N],x12[N],x21[N],x22[N];
	randn(x11,N);
	randn(x12,N);
	randn(x21,N);
	randu(x22,N);
	for (i = 0; i < N; ++i){
		*(x11+i)=*(x11+i)-1;
		*(x12+i)=*(x12+i)-1;
		*(x21+i)=*(x21+i)-1;
		*(x22+i)=*(x22+i)*2-1;
	}
	double yita[N];
	randu(yita,N);
	for (i = 0; i < N; ++i)
		*(yita+i)=*(yita+i)*4-2.0+c*(*(x12+i)+*(x22+i))/2.0;
	double u1[N],u2[N];
	randl(u1,N);
	randl(u2,N);
	for (i = 0; i < N; ++i){
		*(u1+i)=*(u1+i)/(PI/sqrt(3.0));
		*(u2+i)=*(u1+i)/(PI/sqrt(3.0));
	}
// d1 d2 and x
	for (i = 0; i < N; ++i){
		*(d1+i)=(*(x11+i)-*(x12+i)-*(yita+i)+*(u1+i))>0?1.0:0.0;
		*(d2+i)=(*(x21+i)-*(x22+i)-*(yita+i)+*(u2+i))>0?1.0:0.0;
	}
	for (i = 0; i < N; ++i){
		*(x+i*4)=*(x11+i);
		*(x+i*4+1)=*(x12+i);
		*(x+i*4+2)=*(x21+i);
		*(x+i*4+3)=*(x22+i);
	}
}

// x=[x11 x12 x21 x22]
double estimate_p(int N, double *Delta, double *d1hat, double *d2hat, double *d1, double *d2, double *x, int L, double trim){
	int i,j;
	int Trim[N];
	// trimming
	for (i = 0; i < N; ++i)
		Trim[i]=((!isnan(d1hat[i]) && !isnan(d2hat[i])) && (d1hat[i]>trim && d1hat[i]<(1-trim)) && (d2hat[i]>trim && d2hat[i]<(1-trim)))?1:0;
	// regression variables
	gsl_vector *Y=gsl_vector_alloc(N);
	gsl_vector *X=gsl_vector_alloc(N);
	gsl_vector *Xresid=gsl_vector_alloc(N);
	gsl_matrix *W=gsl_matrix_alloc(N,1+2*L);
	for (i = 0; i < N; ++i){
		gsl_vector_set(Y,i,Trim[i]==1?(*(x+i*4+2)-*(x+i*4)):0.0);
		gsl_vector_set(X,i,Trim[i]==1?(*(x+i*4+3)-*(x+i*4+1)):0.0);
		gsl_matrix_set(W,i,0,1.0);
		for (j = 0; j < L; ++j){
			gsl_matrix_set(W,i,j+1,Trim[i]==1?pow(d1hat[i],j+1):0.0);
			gsl_matrix_set(W,i,j+L+1,Trim[i]==1?pow(d2hat[i],j+1):0.0);
		}
	}
	// regression
	gsl_vector *delta=gsl_vector_alloc(1+2*L);
	LeastSquare(delta,X,W,0);
	gsl_blas_dgemv(CblasNoTrans,-1.0,W,delta,0.0,Xresid);
	gsl_vector_add(Xresid,X);
	// get beta
	double sum_y=0.0,sum_x=0.0,b;
	for (i = 0; i < N; ++i)
	{
		sum_y+=(gsl_vector_get(Y,i)*gsl_vector_get(Xresid,i));
		sum_x+=pow(gsl_vector_get(Xresid,i),2);
	}
	b=sum_y/sum_x;
	for (i = 0; i < (1+2*L); ++i)
		*(Delta+i)=gsl_vector_get(delta,i);
	// free
	gsl_vector_free(Y);
	gsl_vector_free(X);
	gsl_vector_free(Xresid);
	gsl_vector_free(delta);
	gsl_matrix_free(W);
	// return
	return -1*b;
}

double estimate_h(int N, double *h1, double *h2, double *d1, double *d2, double *x, int L, double trim, int order){
	double d1hat[N], d2hat[N], delta[1+2*L];
	// scores
	KernelSelfRegs(d1hat, d1, x, h1, N, 4, 0,order);
	KernelSelfRegs(d2hat, d2, x, h2, N, 4, 0,order);
	return estimate_p(N, delta, d1hat,d2hat,d1,d2,x,L,trim);
}

typedef struct{
	int N;
	int L;
	double trim;
	int order;
	double *d1;
	double *d2;
	double *x;
	double *x_sd;
	// difference matrix
	gsl_matrix *Dx11;
	gsl_matrix *Dx12;
	gsl_matrix *Dx21;
	gsl_matrix *Dx22;
	// weights
	gsl_matrix *K;
}DATA_CV;

double CrossValidObj_h_loo(DATA_CV *data, int l){
	int i,j,index;
	// propensity scores
	double d1hat[data->N-1],d2hat[data->N-1],fm;
	for (i = 0; i < data->N; ++i){
		fm=0.0;
		index=i>l?(i-1):i;
		if (i!=l){
			*(d1hat+index)=0;
			*(d2hat+index)=0;
			for (j = 0; j < data->N; ++j){
				if (j!=l){
					*(d1hat+index)+=(gsl_matrix_get(data->K,i,j)*(*(data->d1+j)));
					*(d2hat+index)+=(gsl_matrix_get(data->K,i,j)*(*(data->d2+j)));
					fm+=gsl_matrix_get(data->K,i,j);
				}
			}
		*(d1hat+index)/=fm;
		*(d2hat+index)/=fm;
		}
	}
	// preoare data
	double d1[data->N-1],d2[data->N-1],x[4*(data->N-1)];
	for (i = 0; i < data->N; ++i){
		index=i>l?(i-1):i;
		if (i!=l){
			*(d1+index)=*(data->d1+i);
			*(d2+index)=*(data->d2+i);
			for (j = 0; j < 4; ++j)
				*(x+4*index+j)=*(data->x+4*i+j);
		}
	}
	//compute beta
	// trimming
	int N=data->N-1;
	int Trim[N];
	for (i = 0; i < data->N; ++i)
		Trim[i]=(d1hat[i]>data->trim && d1hat[i]<(1-data->trim)) && (d2hat[i]>data->trim && d2hat[i]<(1-data->trim))?1:0;
	// regression variables
	gsl_vector *Y=gsl_vector_alloc(N);
	gsl_matrix *X=gsl_matrix_alloc(N,2+2*data->L);
	for (i = 0; i < N; ++i){
		gsl_vector_set(Y,i,(Trim[i]==1)?(*(x+i*4+2)-*(x+i*4)):0.0);
		gsl_matrix_set(X,i,0,(Trim[i]==1)?(*(x+i*4+3)-*(x+i*4+1)):0.0);
		gsl_matrix_set(X,i,1,1.0);
		for (j = 0; j < data->L; ++j){
			gsl_matrix_set(X,i,j+2,(Trim[i]==1)?pow(d1hat[i],j+1):0.0);
			gsl_matrix_set(X,i,j+data->L+2,(Trim[i]==1)?pow(d2hat[i],j+1):0.0);
		}
	}
	// regression
	gsl_vector *delta=gsl_vector_alloc(2+2*data->L);
	LeastSquare(delta,Y,X,0);
	//
	double beta=(*(data->x+l*4+2)-*(data->x+l*4));
	beta-=(gsl_vector_get(delta,0)*(*(data->x+l*4+3)-*(data->x+l*4+1)));
	beta-=(gsl_vector_get(delta,1));
	double d1hatl=0.0,d2hatl=0.0;
	fm=0.0;
	for (i = 0; i < N; ++i){
		if (i!=l){
			d1hatl+=(gsl_matrix_get(data->K,i,l)*(*(data->d1+i)));
			d2hatl+=(gsl_matrix_get(data->K,i,l)*(*(data->d2+i)));
			fm+=gsl_matrix_get(data->K,i,l);
		}
	}
	d1hatl/=fm;d2hatl/=fm;
	for (j = 0; j < data->L; ++j){
		beta-=(gsl_vector_get(delta,j+2)*pow(d1hatl,j+1));
		beta-=(gsl_vector_get(delta,j+data->L+2)*pow(d2hatl,j+1));
	}
	// free
	gsl_vector_free(Y);
	gsl_matrix_free(X);
	gsl_vector_free(delta);
	// return data
	return pow(beta,2);
}
double CrossValidObj_h(const gsl_vector *h, void *d){
	DATA_CV *data=(DATA_CV *)d;
	int i,j,k;
	if (gsl_vector_get(h,0)<=0){
		return 1.0e5;
	}
	double H[4];
	*(H+0)=gsl_vector_get(h,0)*(*(data->x_sd+0))*pow(data->N,-1.0/8);
	*(H+1)=gsl_vector_get(h,0)*(*(data->x_sd+1))*pow(data->N,-1.0/8);
	*(H+2)=gsl_vector_get(h,0)*(*(data->x_sd+2))*pow(data->N,-1.0/8);
	*(H+3)=gsl_vector_get(h,0)*(*(data->x_sd+3))*pow(data->N,-1.0/8);
	// compute K
	double Ktemp;
	for (i = 0; i < data->N; ++i){
		for (j = i; j < data->N; ++j){
			Ktemp =Kernel(gsl_matrix_get(data->Dx11,i,j)/(*(H+0)),data->order);
			Ktemp*=Kernel(gsl_matrix_get(data->Dx12,i,j)/(*(H+1)),data->order);
			Ktemp*=Kernel(gsl_matrix_get(data->Dx21,i,j)/(*(H+2)),data->order);
			Ktemp*=Kernel(gsl_matrix_get(data->Dx22,i,j)/(*(H+3)),data->order);
			gsl_matrix_set(data->K,i,j,Ktemp);
			if (i!=j)
				gsl_matrix_set(data->K,j,i,gsl_matrix_get(data->K,i,j));
		}
	}
	double sum=0.0;
	#pragma omp parallel for reduction(+:sum)
	for (i = 0; i < data->N; ++i)
		sum+=CrossValidObj_h_loo(data,i);
	return sum/data->N;
}
double estimate_cv(double *h, double *d1, double *d2, double *x, int N, int L, double trim, int order, int MaxIter, double tol, int warn){
	DATA_CV data;
	data.N=N; data.L=L; data.trim=trim; data.d1=d1; data.d2=d2; data.x=x; data.order=order;
	int i,j; double x_sd[4];
	for (i = 0; i < 4; ++i)
		*(x_sd+i)=gsl_stats_sd(x+i,4,N);
	data.x_sd=x_sd;
	// difference
	gsl_matrix *Dx11=gsl_matrix_alloc(N,N);
	gsl_matrix *Dx12=gsl_matrix_alloc(N,N);
	gsl_matrix *Dx21=gsl_matrix_alloc(N,N);
	gsl_matrix *Dx22=gsl_matrix_alloc(N,N);
	for (i = 0; i < N; ++i){
		for (j = i; j < N; ++j){
			gsl_matrix_set(Dx11,i,j,*(x+4*i)-*(x+4*j));
			gsl_matrix_set(Dx12,i,j,*(x+4*i+1)-*(x+4*j+1));
			gsl_matrix_set(Dx21,i,j,*(x+4*i+2)-*(x+4*j+2));
			gsl_matrix_set(Dx22,i,j,*(x+4*i+3)-*(x+4*j+3));
			if (j!=i){
				gsl_matrix_set(Dx11,j,i,gsl_matrix_get(Dx11,i,j));
				gsl_matrix_set(Dx12,j,i,gsl_matrix_get(Dx12,i,j));
				gsl_matrix_set(Dx21,j,i,gsl_matrix_get(Dx21,i,j));
				gsl_matrix_set(Dx22,j,i,gsl_matrix_get(Dx22,i,j));
			}
		}
	}
	data.Dx11=Dx11;
	data.Dx12=Dx12;
	data.Dx21=Dx21;
	data.Dx22=Dx22;
	// Weights
	gsl_matrix *K=gsl_matrix_alloc(N,N);
	data.K=K;
	// start cross validation
	gsl_vector *v=gsl_vector_alloc(1);
	gsl_vector *s=gsl_vector_alloc(1);
	gsl_vector_set(v,0,5.5);
	gsl_vector_set(s,0,6.6);
	const gsl_multimin_fminimizer_type *T=gsl_multimin_fminimizer_nmsimplex2;
	gsl_multimin_fminimizer *fmini=gsl_multimin_fminimizer_alloc(T,1);
	gsl_multimin_function Obj;
	Obj.n=1;Obj.f=CrossValidObj_h;Obj.params=&data;
	gsl_multimin_fminimizer_set(fmini,&Obj,v,s);
	// iterate
	int iter=0; int status=0; double size;
	do{
		iter++;
		status=gsl_multimin_fminimizer_iterate(fmini);
		if(status>0 && warn==1){
			printf("The Cross Validation Procedure does not converge....\n");
			break;
		}
		size=gsl_multimin_fminimizer_size(fmini);
		status=gsl_multimin_test_size(size,tol);
	}while(status==GSL_CONTINUE && iter<MaxIter);
	// the estimate
	double H[4];
	*h=gsl_vector_get(fmini->x,0);
	*(H+0)=*h*(*(data.x_sd+0))*pow(data.N,-1.0/8);
	*(H+1)=*h*(*(data.x_sd+1))*pow(data.N,-1.0/8);
	*(H+2)=*h*(*(data.x_sd+2))*pow(data.N,-1.0/8);
	*(H+3)=*h*(*(data.x_sd+3))*pow(data.N,-1.0/8);
	double beta=estimate_h(N, H, H, d1, d2, x, L, trim, order);
	// free
	gsl_matrix_free(Dx11);
	gsl_matrix_free(Dx12);
	gsl_matrix_free(Dx21);
	gsl_matrix_free(Dx22);
	gsl_matrix_free(K);
	gsl_vector_free(v);
	gsl_vector_free(s);
	gsl_multimin_fminimizer_free(fmini);
	return beta;
}

double CrossValidObj_h2(const gsl_vector *h, void *d){
	DATA_CV *data=(DATA_CV *)d;
	int i,j,k;
	if (gsl_vector_get(h,0)<=0){
		return 1.0e5;
	}
	double H[4];
	*(H+0)=gsl_vector_get(h,0)*(*(data->x_sd+0))*pow(data->N,-1.0/8);
	*(H+1)=gsl_vector_get(h,0)*(*(data->x_sd+1))*pow(data->N,-1.0/8);
	*(H+2)=gsl_vector_get(h,1)*(*(data->x_sd+2))*pow(data->N,-1.0/8);
	*(H+3)=gsl_vector_get(h,1)*(*(data->x_sd+3))*pow(data->N,-1.0/8);
	// compute K
	double Ktemp;
	for (i = 0; i < data->N; ++i){
		for (j = i; j < data->N; ++j){
			Ktemp =Kernel(gsl_matrix_get(data->Dx11,i,j)/(*(H+0)),data->order);
			Ktemp*=Kernel(gsl_matrix_get(data->Dx12,i,j)/(*(H+1)),data->order);
			Ktemp*=Kernel(gsl_matrix_get(data->Dx21,i,j)/(*(H+2)),data->order);
			Ktemp*=Kernel(gsl_matrix_get(data->Dx22,i,j)/(*(H+3)),data->order);
			gsl_matrix_set(data->K,i,j,Ktemp);
			if (i!=j)
				gsl_matrix_set(data->K,j,i,gsl_matrix_get(data->K,i,j));
		}
	}
	double sum=0.0;
	#pragma omp parallel for reduction(+:sum)
	for (i = 0; i < data->N; ++i)
		sum+=CrossValidObj_h_loo(data,i);
	return sum/data->N;
}
double estimate_cv2(double *h, double *d1, double *d2, double *x, int N, int L, double trim, int order, int MaxIter, double tol, int warn){
	DATA_CV data;
	data.N=N; data.L=L; data.trim=trim; data.d1=d1; data.d2=d2; data.x=x; data.order=order;
	int i,j; double x_sd[4];
	for (i = 0; i < 4; ++i)
		*(x_sd+i)=gsl_stats_sd(x+i,4,N);
	data.x_sd=x_sd;
	// difference
	gsl_matrix *Dx11=gsl_matrix_alloc(N,N);
	gsl_matrix *Dx12=gsl_matrix_alloc(N,N);
	gsl_matrix *Dx21=gsl_matrix_alloc(N,N);
	gsl_matrix *Dx22=gsl_matrix_alloc(N,N);
	for (i = 0; i < N; ++i){
		for (j = i; j < N; ++j){
			gsl_matrix_set(Dx11,i,j,*(x+4*i)-*(x+4*j));
			gsl_matrix_set(Dx12,i,j,*(x+4*i+1)-*(x+4*j+1));
			gsl_matrix_set(Dx21,i,j,*(x+4*i+2)-*(x+4*j+2));
			gsl_matrix_set(Dx22,i,j,*(x+4*i+3)-*(x+4*j+3));
			if (j!=i){
				gsl_matrix_set(Dx11,j,i,gsl_matrix_get(Dx11,i,j));
				gsl_matrix_set(Dx12,j,i,gsl_matrix_get(Dx12,i,j));
				gsl_matrix_set(Dx21,j,i,gsl_matrix_get(Dx21,i,j));
				gsl_matrix_set(Dx22,j,i,gsl_matrix_get(Dx22,i,j));
			}
		}
	}
	data.Dx11=Dx11;
	data.Dx12=Dx12;
	data.Dx21=Dx21;
	data.Dx22=Dx22;
	// Weights
	gsl_matrix *K=gsl_matrix_alloc(N,N);
	data.K=K;
	// start cross validation
	gsl_vector *v=gsl_vector_alloc(2);
	gsl_vector *s=gsl_vector_alloc(2);
	gsl_vector_set(v,0,5.5);
	gsl_vector_set(s,0,6.6);
	gsl_vector_set(v,1,5.5);
	gsl_vector_set(s,1,6.6);
	const gsl_multimin_fminimizer_type *T=gsl_multimin_fminimizer_nmsimplex2;
	gsl_multimin_fminimizer *fmini=gsl_multimin_fminimizer_alloc(T,2);
	gsl_multimin_function Obj;
	Obj.n=2;Obj.f=CrossValidObj_h2;Obj.params=&data;
	gsl_multimin_fminimizer_set(fmini,&Obj,v,s);
	// iterate
	int iter=0; int status=0; double size;
	do{
		iter++;
		status=gsl_multimin_fminimizer_iterate(fmini);
		if(status>0 && warn==1){
			printf("The Cross Validation Procedure does not converge....\n");
			break;
		}
		size=gsl_multimin_fminimizer_size(fmini);
		status=gsl_multimin_test_size(size,tol);
	}while(status==GSL_CONTINUE && iter<MaxIter);
	// the estimate
	double H[4];
	*h=gsl_vector_get(fmini->x,0);
	*(h+1)=gsl_vector_get(fmini->x,1);
	*(H+0)=*(h+0)*(*(data.x_sd+0))*pow(data.N,-1.0/8);
	*(H+1)=*(h+0)*(*(data.x_sd+1))*pow(data.N,-1.0/8);
	*(H+2)=*(h+1)*(*(data.x_sd+2))*pow(data.N,-1.0/8);
	*(H+3)=*(h+1)*(*(data.x_sd+3))*pow(data.N,-1.0/8);
	double beta=estimate_h(N, H, H, d1, d2, x, L, trim, order);
	// free
	gsl_matrix_free(Dx11);
	gsl_matrix_free(Dx12);
	gsl_matrix_free(Dx21);
	gsl_matrix_free(Dx22);
	gsl_matrix_free(K);
	gsl_vector_free(v);
	gsl_vector_free(s);
	gsl_multimin_fminimizer_free(fmini);
	return beta;
}
typedef struct{
	int N;
	int order;
	int *d;
	double h;
	double *dx;
}DATA_SMS;
double Kernel01(double d, int order){
	if (order==-1){
		return (d>0)?1:-1;
	}else if (order==2){
		return normcdf(d);
	}else if (order==4){
		if (d<-5)
		{
			return 0.0;
		}else if (d>5)
		{
			return 1.0;
		}else{
			double v=d/5,k,vp=v,v2=pow(v,2);
			double c[]={1.0, -5.0/3, 7.0/5, -3.0/7,};
			int i;
			for (i = 0; i < 4; ++i){
				k+=vp*c[i];
				vp*=v2;
			}
			return 0.5+1.640625*k;
		}
	}
}
double SMSObj(const gsl_vector *b, void *d){
	DATA_SMS *data=(DATA_SMS *)d;
	double obj=0.0,o,bw[data->N],fm;
	int i;
	double sigma;
	double bb=gsl_vector_get(b,0);
	#pragma omp parallel for
	for (int i = 0; i < data->N; ++i) bw[i]=*(data->dx+i*2)+*(data->dx+i*2+1)*bb;
	// sigma=data->h*pow(data->N,-1.0/(1+2*data->order))*gsl_stats_sd(bw,1,data->N);
	sigma=data->h*pow(data->N,-1.0/(1+2*data->order));
	fm=data->order==-1?1.0:sigma;
	#pragma omp parallel for reduction(+:obj) private(o)
	for (i = 0; i < data->N; ++i){
		o=(*(data->d+i)==0?0.0:(double)*(data->d+i)*Kernel01(bw[i]/fm,data->order));
		obj+=o;
	}
	return -1*obj/data->N;
}
double SmoothedMaximumScore(int *d, double *dx,int N, int order, double h, int MaxIter, double tol, int warn){
	DATA_SMS data;
	data.N=N; data.d=d; data.dx=dx; data.order=order; data.h=h;
	int i,j;
	// start cross validation
	gsl_vector *v=gsl_vector_alloc(1);
	gsl_vector *s=gsl_vector_alloc(1);
	gsl_vector_set(v,0,-1.2);
	gsl_vector_set(s,0,-0.8);
	const gsl_multimin_fminimizer_type *T=gsl_multimin_fminimizer_nmsimplex2;
	gsl_multimin_fminimizer *fmini=gsl_multimin_fminimizer_alloc(T,1);
	gsl_multimin_function Obj;
	Obj.n=1;Obj.f=SMSObj;Obj.params=&data;
	gsl_multimin_fminimizer_set(fmini,&Obj,v,s);
	// iterate
	int iter=0; int status=0; double size;
	do{
		iter++;
		status=gsl_multimin_fminimizer_iterate(fmini);
		if(status>0 && warn==1){
			printf("The Cross Validation Procedure does not converge....\n");
			break;
		}
		size=gsl_multimin_fminimizer_size(fmini);
		status=gsl_multimin_test_size(size,tol);
	}while(status==GSL_CONTINUE && iter<MaxIter);
	double b=gsl_vector_get(fmini->x,0);
	// free
	gsl_vector_free(v);
	gsl_vector_free(s);
	gsl_multimin_fminimizer_free(fmini);
	return b;
}
double SMSObj_ls(double bb, void *d){
	DATA_SMS *data=(DATA_SMS *)d;
	double obj=0.0,o,bw[data->N],fm;
	int i;
	double sigma;
	#pragma omp parallel for
	for (int i = 0; i < data->N; ++i) bw[i]=*(data->dx+i*2)+*(data->dx+i*2+1)*bb;
	// sigma=data->h*pow(data->N,-1.0/(1+2*data->order))*gsl_stats_sd(bw,1,data->N);
	sigma=data->h*pow(data->N,-1.0/(1+2*data->order));
	fm=data->order==-1?1.0:sigma;
	#pragma omp parallel for reduction(+:obj) private(o)
	for (i = 0; i < data->N; ++i){
		o=(*(data->d+i)==0?0.0:(double)*(data->d+i)*Kernel01(bw[i]/fm,data->order));
		obj+=o;
	}
	return -1*obj/data->N;
}
double SmoothedMaximumScore_ls(int *d, double *dx,int N, int order, double h){
	DATA_SMS data;
	data.N=N; data.d=d; data.dx=dx; data.order=order; data.h=h;
	return gridSearch1(-4.0,0.0,30,3,&data,SMSObj_ls);
}

typedef struct{
	int N;
	int *d1;
	int *d2;
	double *dx;
}DATA_ConditionalLogit;

double ConditionalLogitObj(const gsl_vector *b, void *d){
	DATA_ConditionalLogit *data=(DATA_ConditionalLogit *)d;
	int i;
	double xb,obj,eps=1e-5;
	double b0=gsl_vector_get(b,0),b1=gsl_vector_get(b,1);
	#pragma omp parallel for reduction(+:obj) private(xb)
	for (i = 0; i < data->N; ++i){
		if (*(data->d1+i)+*(data->d2+i)==1){
			xb=*(data->dx+i*2)*b0+*(data->dx+i*2+1)*b1;
			xb=exp(xb);
			xb=xb/(1+xb);
			xb=(xb>(1-eps)?1-eps:xb); xb=(xb<eps?eps:xb);
			obj+=( *(data->d2+i)==1?log(xb):log(1-xb) );
		}
	}
	return -1*obj/data->N;
}

void ConditionalLogit(double *b, int *d1, int *d2, double *dx, int N, int warn, double tol, int MaxIter){
	DATA_ConditionalLogit data;
	data.N=N; data.d1=d1; data.d2=d2; data.dx=dx;
	// start cross validation
	gsl_vector *v=gsl_vector_alloc(2);
	gsl_vector *s=gsl_vector_alloc(2);
	gsl_vector_set(v,0,2.0);
	gsl_vector_set(v,1,-2.0);
	gsl_vector_set(s,0,2.2);
	gsl_vector_set(s,1,-1.8);
	const gsl_multimin_fminimizer_type *T=gsl_multimin_fminimizer_nmsimplex2;
	gsl_multimin_fminimizer *fmini=gsl_multimin_fminimizer_alloc(T,2);
	gsl_multimin_function Obj;
	Obj.n=2;Obj.f=ConditionalLogitObj;Obj.params=&data;
	gsl_multimin_fminimizer_set(fmini,&Obj,v,s);
	// iterate
	int iter=0; int status=0; double size;
	do{
		iter++;
		status=gsl_multimin_fminimizer_iterate(fmini);
		if(status>0 && warn==1){
			printf("The Cross Validation Procedure does not converge....\n");
			break;
		}
		size=gsl_multimin_fminimizer_size(fmini);
		status=gsl_multimin_test_size(size,tol);
	}while(status==GSL_CONTINUE && iter<MaxIter);
	*b=gsl_vector_get(fmini->x,0);
	*(b+1)=gsl_vector_get(fmini->x,1);
	// free
	gsl_vector_free(v);
	gsl_vector_free(s);
	gsl_multimin_fminimizer_free(fmini);
	return;
}

int main(int argc, char const *argv[])
{
	int N=500,i,Iter=500,iter,order=4;
	// the s.d. of x
	double sd[4];
	double d1[N],d2[N],x[N*4],b;
	double h1[4],h2[4],h;
	// h=7.0;
	// for (iter = 0; iter < Iter; ++iter)
	// {
	// 	// Generate data
	// 	DGP(d1,d2,x,N,0);
	// 	for (i = 0; i < 4; ++i)
	// 		*(sd+i)=gsl_stats_sd(x+i,4,N);
	// 	*(h1+0)=h*(*(sd+0))*pow(N,-1.0/8);
	// 	*(h1+1)=h*(*(sd+1))*pow(N,-1.0/8);
	// 	*(h1+2)=h*(*(sd+2))*pow(N,-1.0/8);
	// 	*(h1+3)=h*(*(sd+3))*pow(N,-1.0/8);
	// 	// for (i = 0; i < N; ++i)
	// 	// {
	// 	// 	printf("%f,%f,%f,%f,%f,%f\n", *(d1+i),*(d2+i),*(x+4*i),*(x+4*i+1),*(x+4*i+2),*(x+4*i+3));
	// 	// }
	// 	//estimate
	// 	b=estimate_h(N,h1,h1,d1,d2,x,3,0.025);
	// 	printf("%f\n", b);
	// }
	for (iter = 0; iter < Iter; ++iter)
	{
		DGP(d1,d2,x,N,1);
		b=estimate_cv(&h,d1,d2,x,N,3,0.025, order, 5000, 0.5, 0);
		printf("%f, h=%f\n", b, h);
	}
	return 0;
}