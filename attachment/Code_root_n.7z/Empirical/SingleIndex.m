function result=SingleIndex(d,x,iter)
if nargin<4
    iter=500;
end
h=1.06;
ig=Logit(d,x);
ig=ig.beta'/ig.beta(1);
options=optimset('Display','notify','MaxIter',iter);
gamma=fminsearch(@(ga) siobjc(ga,d+0,x),[ig(2:length(ig)),h],options);
result.beta=[1 gamma(1:length(gamma)-1)]';
result.yhat=x*result.beta;
[result.loglikelihood,result.phat]=siobjc(gamma,d+0,x);
result.h=gamma(length(gamma));