function result=Logit(d,x,iter)
warning('off');
if nargin<3
    iter=1000;
end
%% remove NaN
d_nan=any(isnan([d,x]),2);
d=d(~d_nan);
x=x(~d_nan,:);
%% initial guess
ig_ols=(x'*x)\(x'*d);
%% fminunc
opts = optimoptions(@fminunc,...
    'GradObj','on',...
    'Hessian','off',...
    'Diagnostics','off','Display','notify',...
    'MaxIter',iter,'MaxFunEvals',100*iter);
ig=[];
f=[];
ef=[];
multi=2.^(-2:2:6);
for i=multi
    try
        [gamma1,f1,ef1]=fminunc(@(ga) logit_obj(ga,d,x),ig_ols'*i,opts);
%         [gamma1,f1,ef1]=fminsearch(@(ga) logit_obj(ga,d,x),ig_ols'*i,optimset('MaxFunEvals',100*iter,'MaxIter',iter));
    catch err
        if size(ig,1)==0
            continue;
        else
            break;
        end
    end
    if size(ig,1)==0
        ig=gamma1;
        f=f1;
        ef=ef1;
    elseif f1<f
        ig=gamma1;
        f=f1;
        ef=ef1;
    end
end
%% quasi-newton
% [gamma,f,ef]=fminunc(@(ga) logit_obj(ga,d,x),ig,opts);
%% fminsearch
% [gamma,f,ef]=fminsearch(@(ga) logit_obj(ga,d,x),ig,optimset('MaxFunEvals',100*iter,'MaxIter',iter));
%% global search
% opts = optimoptions(@fmincon,...
%     'GradObj','on',...
%     'Hessian','off',...
%     'Diagnostics','off','Display','notify-detailed',...
%     'MaxIter',iter,'MaxFunEvals',100*iter);
% problem=createOptimProblem('fmincon',...
%     'objective',@(ga)logit_obj(ga,d,x),...
%     'x0',ig,...
%     'options',opts);
% gs=GlobalSearch;
% [gamma,f,ef]=run(gs,problem);
%% return result
% result.beta=gamma';
result.beta=ig';
d_nan_index=(1:length(~d_nan));
d_nan_index=d_nan_index(~d_nan);
result.yhat=zeros(length(~d_nan),1)+nan;
result.yhat(d_nan_index)=x*result.beta;
z=exp(result.yhat);
result.phat=z./(1+z);
result.likelihood=f;
result.existflag=ef;
result.N=sum(d_nan);
%% variance
z=exp(x*result.beta);
eps=0.00001;
g=z./((1+z).^2);
G=z./(1+z);
e1=G<=eps;
e2=G>=(1-eps);
e=1-e1-e2;
G=e.*G+e1.*eps+e2.*(1-eps);
GG=G.*(1-G);
H=(g.^2)./GG;
H=bsxfun(@times,x,H);
result.variance=(x'*H)\eye(size(x,2));
result.se=sqrt(diag(result.variance));
result.t=result.beta./result.se;
%% objective function
function [f,s]=logit_obj(gamma,y,x)
z=exp(x*gamma');
g=z./((1+z).^2);
G=z./(1+z);
GG=G.*(1-G);
f=(-1/length(y))*nansum(y.*log(G)+(1-y).*log(1-G));
s=(g.*(y-G))./GG;
s=(-1/length(y))*nansum(bsxfun(@times,x,s));