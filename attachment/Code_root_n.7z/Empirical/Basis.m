%%  Author:   Aragorn(ָ�¾�ʿ)
%%  http://www.zyzen.cn
%%  http://weibo.com/sijichun

%%  Notes
%  Compute the power series or Fourier bases
%     se: the series
%     L: the order
%     app: 'p' for polynomial and 'f' for fourier
%
%  Output:
%    Q: the matrix
function Q=Basis(se,L,app,inter)
if nargin<=3
    inter=0;
end
if nargin<=2
    app='p';
end
len=size(se,2);
index=1:len;
if app=='p' && inter==1
    Q=[];
    for i=1:L
        if len>i
            comb=combntns(index,i);
        else
            break;
        end
        n=size(comb,1);
        if i>1
            Q=[Q,se.^i];
        end
        for j=1:n
            Q=[Q,prod(se(:,comb(j,:)),2)];
        end
    end
elseif app=='p' && inter==0
    Q=[];
    for i=1:L
        Q=[Q,se.^i];
    end
elseif app=='f' && len==1
    Q=zeros(length(se),2*L);
    for i=1:L
        Q(:,2*i-1)=sin(i*se);
        Q(:,2*i)=cos(i*se);
    end
else
    Q=se;
    display('Sth wrong!')
end