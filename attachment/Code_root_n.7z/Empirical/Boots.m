function bt=Boots(samplesize,k,data,para,index_y,L,iter,gamma_p,index)
Coe_gamma=zeros(samplesize,k);
Coe_beta=Coe_gamma;
RSdata=ReSample(data,samplesize);
result=cell(samplesize,1);
gamma_pp=gamma_p(index);
parfor it=1:samplesize
    result{it}=PanelBinary(RSdata{it},para,index_y,L,iter);
    if gamma_pp*result{it}.beta(index)<0
        Coe_beta(it,:)=-1*result{it}.beta';
    else
        Coe_beta(it,:)=result{it}.beta';
    end
    Coe_gamma(it,:)=result{it}.gamma';
end
se_gamma=std(Coe_gamma)';
se_beta=std(Coe_beta)';
bt.se_gamma=se_gamma;
bt.se_beta=se_beta;
%% refine
refine=zeros(4,length(gamma_p));
for i=1:length(se_gamma)
    if se_gamma(i)~=0
        ti=abs((Coe_gamma(:,i)-gamma_p(i))/se_gamma(i));
        ti=sort(ti);
        refine(1,i)=quantile(ti,.9);
        refine(2,i)=quantile(ti,.95);
        refine(3,i)=quantile(ti,.99);
        t=abs(gamma_p(i)/se_gamma(i));
        for tit=1:length(ti)-1
            if tit==1 && t<ti(1)
                refine(4,i)=1;
            elseif t==length(tit) && t>ti(length(ti))
                refine(4,i)=0;
            elseif t>=ti(tit) && t<ti(tit+1)
                refine(4,i)=1-(tit/length(ti));
            end
        end
    end
end
bt.refine=refine';