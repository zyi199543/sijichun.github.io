%%  Author:   Aragorn(ָ�¾�ʿ)
%%  http://www.zyzen.cn
%%  http://weibo.com/sijichun

%%  Notes
%  Compute the panel data sample selection model
%     data: a structure
%     h: the bandwidth
%     L: the order of polinomial approximation
%     app: 'p' for polynomial and 'f' for fourier
%
%  Output:
%    beta: the estimated coefficient of outcome equation
%    gama: the estimated coefficient of selection equation

function result=PanelBinary(data,para,index_y,L,iter)
d=para.d;
wc=para.wc;
wcf=para.wcf;
wd=para.wd;
wdf=para.wdf;
wexclu=para.exclu;
T=data.T;
N=data.N;
%% get the index of d and x
Kc=length(indexof(data.dic,wc));
Kcf=length(indexof(data.dic,wcf));
Kd=length(indexof(data.dic,wd));
Kdf=length(indexof(data.dic,wdf));
%% add mean
[data,addDic]=InsertMean(data,wc);
data=Long2panel(Panel2long(data,1),data.dic);
if ~isempty(wexclu)
    for l=length(addDic):-1:1
        for ll=1:length(wexclu)
            if strcmp(addDic{l},['Mean',wexclu{ll}])
                addDic(l)=[];
                continue;
            end
        end
    end
end
%% get data;
data_d=cell(T,1);
data_wc=cell(T,1);
data_wcf=cell(T,1);
data_wd=cell(T,1);
data_wdf=cell(T,1);
data_wcm=cell(T,1);
for t=1:T
    data_t=Panel2long(SubData(data,[{'ind','time'},d,wc,wcf,wd,wdf,addDic],data.indext(t),0,1),1);
    data_d{t}=data_t(:,3);
    data_wc{t}=data_t(:,4:3+Kc);
    if Kcf~=0
        data_wcf{t}=data_t(:,4+Kc:3+Kc+Kcf);
    else
        data_wcf{t}=[];
    end
    if Kd~=0
        data_wd{t}=data_t(:,4+Kc+Kcf:3+Kc+Kcf+Kd);
    else
        data_wd{t}=[];
    end
    if Kdf~=0
        data_wdf{t}=data_t(:,4+Kc+Kcf+Kd:3+Kc+Kcf+Kd+Kdf);
    else
        data_wdf{t}=[];
    end
    data_wcm{t}=data_t(:,4+Kc+Kcf+Kd+Kdf:3+Kc+Kcf+Kd+Kdf+Kc-length(wexclu));
end
clear data_t data;
%% compute the propensity score by year
ps=cell(T,1);
re=cell(T,1);
for t=1:T
    re{t}=Logit(data_d{t},[ones(N,1) data_wc{t} Basis([data_wcm{t} data_wcf{t}],3,'p',1) data_wd{t} data_wdf{t}],iter);
    ps{t}=re{t}.phat;
end
clear re;
%% trimming
for i=size(ps,1):-1:1
    for t=1:T
        if ps{t}(i)<0.05 || ps{t}(i)>0.95
            ps{t}(i)=nan;
        end
    end
end
clear tt data_wcf data_wdf;
%% generate polynomial and the new dataset
data_Q=cell(T,1);
% data_F=cell(T,1);
data_X=cell(T,1);
for t=1:T
    data_Q{t}=[Basis(10*ps{t},L,'p'),ones(N,1)];
%     data_F{t}=Basis(ps{t},L,'p');
    data_X{t}=[data_wc{t} data_wd{t}];
end
L=L+1;
clear data_wc data_wcf data_wd data_wdf
%% prepare the matrices and compute the results
X=[];Q=[];
Nt=size(data_X{1},1);
for t=2:T
    for tt=1:t
        X=[X;data_X{t}-data_X{t-1}];
        Qt=zeros(Nt,T*L);
        Qt(:,(t-1)*L+1:t*L)=data_Q{t};
        Qt(:,(tt-1)*L+1:tt*L)=-1*data_Q{tt};
        Q=[Q;Qt];
    end
end
clear Qt
%% del nan
d_nan=any(isnan([X,Q]),2);
X=X(~d_nan,:);
k1=size(X,2);
NT=size(X,1);
Q=Q(~d_nan,:);
%% use ols
if index_y~=0
    W=[X,Q];
    Y=W(:,index_y);
    W(:,index_y)=[];
    gamma=(W'*W)\(W'*Y);
    if index_y==1
        gamma=[-1;gamma];
    else
        gamma=[gamma(1:index_y-1);-1;gamma(index_y:length(gamma))];
    end
    result.gamma=gamma(1:k1);
    result.delta=gamma(k1+1:length(gamma));
end
%% new method
Q(:,size(Q,2))=[];
Xp=X-Q*((Q'*Q)\(Q'*X));
[V,D]=eig(Xp'*Xp);
clear Xp
m=D(1,1);
beta=V(:,1);
for i=1:size(X,2)
    if D(i,i)<m
        m=D(i,i);
        beta=V(:,i);
    end
end
result.beta=beta;
%% results
result.NT=NT;
result.index_y=index_y;
