warning('off');
clear
load S2_SOEP
para.d={'employment'};
para.wc={'chld16','age2','logIncome','husworkhour'};
para.wcf={'edu','logAveIncome'};
para.wd={'chld6','husemployment'};
para.wdf={'MaxChld6','region'};
para.exclu={'logIncome'};
%% iteration
iter=5000;% if Logit
%% sample size of bootstrap
samplesize=1000;
%% y variable
y=2;
% order of polynomial
L=5;
%% begin
tic
result=PanelBinary(data,para,y,L,iter);
result.gamma
result.beta
BT=Boots(samplesize,length(result.gamma),data,para,y,L,iter,result.gamma,5);
a1=[result.gamma BT.se_gamma result.gamma./BT.se_gamma BT.refine(:,4)]
BT.refine
b1=[result.beta BT.se_beta result.beta./BT.se_beta]
result.NT
toc
save RESULTS_SOEP